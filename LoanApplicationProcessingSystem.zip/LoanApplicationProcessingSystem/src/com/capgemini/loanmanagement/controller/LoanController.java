package com.capgemini.loanmanagement.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.loanmanagement.bean.ApprovedLoans;
import com.capgemini.loanmanagement.bean.CustomerDetails;
import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;
import com.capgemini.loanmanagement.bean.Users;
import com.capgemini.loanmanagement.service.ILAPService;
import com.capgemini.loanmanagement.service.ILoanProgramOfferedservice;




@Controller
public class LoanController {

	@Autowired
	ILAPService LAPService;
	@Autowired
	ILoanProgramOfferedservice loanService;
	
	static CustomerDetails custDetails;
	static Users user;
	static String userId;
	static String applicantName;
	static long idForUpdate;
	static ApprovedLoans approvedLoans;
	
	//FOR HOMEPAGE
	@RequestMapping(value="homepage", method=RequestMethod.GET)
	public String  getHomePage(@ModelAttribute("viewStatus") LoanApplication loan){
		
		return "homepage";
		
	}
	
	//FOR LOGIN
	@RequestMapping(value="login", method=RequestMethod.GET)
	public String  getLoginPage(@ModelAttribute("my") Users user){
		
		return "login";
		
	}
	
	//FOR SIGNUP
	@RequestMapping(value="signup", method=RequestMethod.GET)
	public String  getSignUpPage(@ModelAttribute("my") CustomerDetails customerDetails,Map<String, Object> model){
		short status=1;
	
		model.put("status", status);		
		return "signup";
		
	}
	
	//FOR REGISTRATION
	@RequestMapping(value="register", method=RequestMethod.POST)
	public String  getRegister(@ModelAttribute("my")CustomerDetails customerDetails,@ModelAttribute
			("confirmReg")Users users,Map<String, Object> model){
		short status=2;
		/**/
		model.put("status", status);
		custDetails=customerDetails;
		return "signup";
		
	}
	
	//FOR CONFRIM PASSWORD
	@RequestMapping(value="confirm", method=RequestMethod.POST)
	public String  getRegisterConfirm(@RequestParam("rePassword") String repassword,@ModelAttribute("confirmReg")Users users,@ModelAttribute("my") 
	CustomerDetails customerDetails,Map<String, Object> model){
		
		if(repassword.equals(users.getPassword())){
			boolean checkName=LAPService.getCustomerName(users.getLogin_Id());
			if(checkName==true){
				LAPService.insertUserDetails(users);
				custDetails.setLogin_Id(users.getLogin_Id());
				LAPService.insertCustomerDetails(custDetails);
				model.put("userName", users.getLogin_Id());
				model.put("custDetails", custDetails);
				List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
				model.put("loanOffered", list);
				return "customer";
			}else{
				short status=2;
				model.put("checkName", checkName);
				model.put("status", status);
				return "signup";
			}
		}else{
			short status=2;
			boolean passNotMatch=true;
			model.put("passNotMatch", passNotMatch);
			model.put("status", status);
			return "signup";
		}

	}
	
	//LOGIN
	@RequestMapping(value="loginUser", method=RequestMethod.POST)
	public ModelAndView showAll(@ModelAttribute("my") Users users1,@ModelAttribute("setDate") LoanApplication application,@Valid@ModelAttribute("my") Users user,@ModelAttribute("loanProg") 
	LoanProgramsOffered loanProgramsOffered,BindingResult result,Map<String, Integer> data,Map<String, 
	Object> model){
		CustomerDetails cDetails=new CustomerDetails();
		String role = null;
		if(result.hasErrors()){
			return new ModelAndView("login");
		}
		List<Users> userList = LAPService.getDetailsListUsers(user);
		if(userList.isEmpty()){
			model.put("notUser", 1);
			return new ModelAndView("login");
		}
		for(Users users:userList){
			if(users.getRole()==null){
				model.put("userName", users.getLogin_Id());
				List<CustomerDetails> customerDetails=LAPService.selectAllCustomerDetails(users.getLogin_Id());
				for( CustomerDetails details:customerDetails){
					cDetails.setApplicant_Id(details.getApplicant_Id());
					cDetails.setApplicant_Name(details.getApplicant_Name());
					cDetails.setCountOfDependents(details.getCountOfDependents());
					cDetails.setDateOfBirth(details.getDateOfBirth());
					cDetails.setEmail_Id(details.getEmail_Id());
					cDetails.setLogin_Id(details.getLogin_Id());
					cDetails.setMaritalStatus(details.getMaritalStatus());
					cDetails.setMobile_Number(details.getMobile_Number());
					cDetails.setPhone_Number(details.getPhone_Number());
					break;
				}
				List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
				model.put("loanOffered", list);
				model.put("custDetails", cDetails);
				List<LoanApplication> loanList=LAPService.getLoanApplied(users.getLogin_Id());
				model.put("loanApplied", loanList);
				return new ModelAndView("customer");
			}
			role=users.getRole();
		}
		System.out.println(role);
		if(role.equals("ADMIN")){
			
			return new ModelAndView("admin","role",role);
		}else if(role.equals("LAD")){
			List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
			/*model.put("loanOffered", loanOffered);*/
			List<LoanApplication> loanApplications=LAPService.getPendingResquest();
			if(loanApplications.isEmpty()){
				model.put("notAvail", true);
			}else{
				model.put("notAvail", false);
			}
			model.put("pending", loanApplications);
			return new ModelAndView("lad","loanOffered",list);
		}else{
			return new ModelAndView("customer");
		}
	}
	
	//VIEW APPLICATION STATUS
	@RequestMapping(value="viewApplicationDetails", method=RequestMethod.POST)
	public ModelAndView  viewApplicationDetails(@ModelAttribute("viewStatus") LoanApplication loan,Map<String, Object>model){
		boolean status=false;
		short temp = 0;
		
		model.put("status", status);
		model.put("temp", temp);
		
		return new ModelAndView("viewApplicationStatusDetails","loan",loan);
		
	}
	
	//RETRIVE LOAN DETAILS
	@RequestMapping(value="performRetrieve",method=RequestMethod.POST)
	public ModelAndView performRetrieve(@ModelAttribute("viewStatus")LoanApplication la,Map<String,Object> model){
		short flag=0;
		
		long Id=la.getApplicationId();
		short temp = 0;
		List<ApprovedLoans> approvedLoans= LAPService.showApproved(Id);
		if(approvedLoans.isEmpty()){
			flag=1;
			
		}
		model.put("flag", flag);
		
		ApprovedLoans approvedLoansDis=new ApprovedLoans();
		for(ApprovedLoans loans:approvedLoans){
			approvedLoansDis.setAmountOfLoanGranted(loans.getAmountOfLoanGranted());
			approvedLoansDis.setDownpayment(loans.getDownpayment());
			approvedLoansDis.setMonthlyInstallment(loans.getMonthlyInstallment());
			approvedLoansDis.setRateOfInterest(loans.getRateOfInterest());
			approvedLoansDis.setTotalAmountPayable(loans.getTotalAmountPayable());
			approvedLoansDis.setYearsTimePeriod(loans.getYearsTimePeriod());
		}
		model.put("approvedLoan", approvedLoansDis);
		List<LoanApplication> list=LAPService.displayStatus(Id);
		if(list.isEmpty()){
			temp = 1;
			model.put("temp", temp);
			return new ModelAndView("viewApplicationStatusDetails");
		}
		boolean status=true;
		model.put("status",status);
		return new ModelAndView("viewApplicationStatusDetails","temp1",list);
	}

	
	@RequestMapping(value="logout", method=RequestMethod.POST)
	public String  getBack(@ModelAttribute("my") Users users){
		
		return "login";
		
	}

	//ADD LOAN PROGRAM
	@RequestMapping(value="ADD",method=RequestMethod.GET)
	public String addLoanProgram(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,Map<String, Object> model){
	List<String> list=new ArrayList<>();
	list.add("Long Term");
	list.add("Short Term");
	model.put("type",list);
	boolean check=false;
	model.put("check",check);
		return "addLoanProgram";
	}
	
	
	@RequestMapping(value="addLoanProgram",method=RequestMethod.POST)
	public String showInsertLoanProgram(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,Map<String,Object> mop){
		boolean status=true;
		List<String> list=new ArrayList<>();
		list.add("Long Term");
		list.add("Short Term");
		mop.put("type",list);
		mop.put("status",status);
		
		return "addLoanProgram";
	}
	
	@RequestMapping(value="addLoanProgramfinally",method=RequestMethod.POST)
	public String insert(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,Map<String,Object> mop){
		String name=loanProgramOffered.getProgramName();
		List<LoanProgramsOffered> list=loanService.getLoanDetailsByName(name);
		mop.put("programName",name);
		boolean stattus=true;
		if(list.isEmpty()){
			List<String> list1=new ArrayList<>();
			list1.add("Long Term");
			list1.add("Short Term");
			mop.put("type",list1);
			mop.put("status", stattus);
			mop.put("stattu", stattus);
		loanService.addLoanProgram(loanProgramOffered);
		return "addLoanProgram";
		}else{
			mop.put("stattus", stattus);
			mop.put("status", stattus);
			List<String> list1=new ArrayList<>();
			list1.add("Long Term");
			list1.add("Short Term");
			mop.put("type",list1);
			return "addLoanProgram";
		}
	}
	
	//UPDATE
	@RequestMapping(value="UPDATE",method=RequestMethod.GET)
	public ModelAndView updateloanProgram(Map<String,Object> mop,@ModelAttribute("my")LoanProgramsOffered loanProgramOffered){
		List<LoanProgramsOffered> list=loanService.getLoanDetails();
		boolean status1=true;
		mop.put("status1",status1);
	return new ModelAndView("Update","list",list);
}
	
	@RequestMapping(value="UpdateData",method=RequestMethod.GET)
	public ModelAndView updateConfirm(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,@RequestParam("loanName")String name,Map<String,Object> mop){
		boolean status=true;
		mop.put("status1",status);
		mop.put("status",status);
		List<LoanProgramsOffered> list=loanService.getLoanDetailsByName(name);
		List<LoanProgramsOffered> list2=loanService.getLoanDetails();
		List<String> list1=new ArrayList<>();
		list1.add("Long Term");
		list1.add("Short Term");
		mop.put("type",list1);
		mop.put("list2",list);
		return new ModelAndView("Update","list",list2);
	}
	
	@RequestMapping(value="updateLoanProgram",method=RequestMethod.POST)
	public String update(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,Map<String,Object> mop){
		loanService.updateLoanProgram(loanProgramOffered);
		boolean status=true;
		mop.put("status1", status);
		mop.put("status", status);
		mop.put("update1", status);
		List<LoanProgramsOffered> list=loanService.getLoanDetailsByName(loanProgramOffered.getProgramName());
		List<LoanProgramsOffered> list2=loanService.getLoanDetails();
		List<String> list1=new ArrayList<>();
		list1.add("Long Term");
		list1.add("Short Term");
		mop.put("type",list1);
		mop.put("list2",list);
		mop.put("list",list2);
		mop.put("name", loanProgramOffered.getProgramName());
		return "Update";
	}
	
	@RequestMapping(value="updateLoan1",method=RequestMethod.POST)
	public String update1(){
		return "failed";
	}
	//FOR DELETE LOAN PROGRAM
	@RequestMapping(value="DeleteData",method=RequestMethod.GET)
	public ModelAndView deleteLoanProgram(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,@RequestParam("loanName")String name,Map<String,Object> mop){
		List<LoanProgramsOffered> list=loanService.getLoanDetails();
		List<LoanProgramsOffered> list2=loanService.getLoanDetailsByName(name);
		boolean status=true;
		mop.put("status2",status);
		mop.put("status1",status);
		mop.put("list",list);
		return new ModelAndView("Update","list2",list2);
	}
@RequestMapping(value="deleteData",method=RequestMethod.POST)
public String deleteLoan(@ModelAttribute("my")LoanProgramsOffered loanProgramOffered,Map<String,Object> mop){
	
	List<LoanProgramsOffered> list=loanService.getLoanDetails();
	List<LoanProgramsOffered> list2=loanService.getLoanDetailsByName(loanProgramOffered.getProgramName());
	boolean update=true;
	mop.put("update",update);
	mop.put("name",loanProgramOffered.getProgramName());
	mop.put("status2",update);
	mop.put("status1",update);
	mop.put("list",list);
	mop.put("list2",list2);
	loanService.deleteLoanProgram(loanProgramOffered.getProgramName());
	return "Update";
}
	
//REPORTS
@RequestMapping(value="applicationStatus",method=RequestMethod.GET)
public String AllApplicationStatus(Map<String,Object> mop)
{	List<LoanApplication> list=loanService.getLoanApplicationDetails();
boolean status=true;
	String name="Loan PROGRAM";
	mop.put("list",list);
	mop.put("name", name);
	mop.put("status",status);
	return "Application";
	}

@RequestMapping(value="acceptedLoanStatus",method=RequestMethod.GET)
public String AllAcceptedApplication(Map<String,Object> mop)
{	 String status="ACCEPTED";
	List<LoanApplication> list=loanService.getLoanApplicationStatus(status);
	boolean status1=true;
	mop.put("status",status1);
	mop.put("name",status);
	mop.put("list",list);
	return "Application";
	}

@RequestMapping(value="allApproved",method=RequestMethod.GET)
public String AllApprovedLoan(Map<String,Object> mop)
{	 String status="APPROVED";
List<LoanApplication> list=loanService.getLoanApplicationStatus(status);
boolean status1=true;
mop.put("status",status1);
mop.put("list",list);
mop.put("name",status);
	
	return "Application";
	}
@RequestMapping(value="allRejected",method=RequestMethod.GET)
public String AllRejectedLoan(Map<String,Object> mop)
{	 String status="REJECTED";
List<LoanApplication> list=loanService.getLoanApplicationStatus(status);
boolean status1=true;
mop.put("status",status1);
mop.put("list",list);
mop.put("name",status);
	return "Application";
	}
@RequestMapping(value="allLoanProgram",method=RequestMethod.GET)
public String AllLoanPrograms(Map<String,Object> mop){
	List<LoanProgramsOffered> list=loanService.getLoanDetails();
	mop.put("list",list);
	boolean status=true;
	mop.put("status1",status);
	return "Application";
}

//DISPLAY LOAN DETAILS FOR LAD
@RequestMapping(value="displayLoanDetails",method=RequestMethod.GET)
public String displayLoanDetails(@ModelAttribute("my") Users users,@ModelAttribute("setDate") LoanApplication application,@RequestParam("loanNameDetail") String loanName, Map<String,Object> mop){
	boolean display=true;
	mop.put("display", display);
	List<LoanProgramsOffered> loanDetails= loanService.getLoanDetailsByName(loanName);
	mop.put("loanDetails", loanDetails);
	List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
	mop.put("loanOffered", list);
	List<LoanApplication> loanApplications=LAPService.getPendingResquest();
	if(loanApplications.isEmpty()){
		mop.put("notAvail", true);
	}else{
		mop.put("notAvail", false);
	}
	mop.put("pending", loanApplications);
	return "lad";
}

//FOR DISPLAYING LOAN DETAILS FOR CUSTOMER
@RequestMapping(value="displayLoanDetailsCustomer",method=RequestMethod.GET)
public String displayLoanDetailsCustomer(@ModelAttribute("my") Users users,@ModelAttribute("offered") LoanProgramsOffered offered,@RequestParam("login_Id") String login_Id,@RequestParam("loanNameDetail") String loanName, Map<String,Object> mop){
	boolean display=true;
	CustomerDetails cDetails=new CustomerDetails();
	mop.put("display", display);
	userId=login_Id;
	mop.put("userName", login_Id);
	List<CustomerDetails> customerDetails=LAPService.selectAllCustomerDetails(login_Id);
	for( CustomerDetails details:customerDetails){
		cDetails.setApplicant_Id(details.getApplicant_Id());
		cDetails.setApplicant_Name(details.getApplicant_Name());
		cDetails.setCountOfDependents(details.getCountOfDependents());
		cDetails.setDateOfBirth(details.getDateOfBirth());
		cDetails.setEmail_Id(details.getEmail_Id());
		cDetails.setLogin_Id(details.getLogin_Id());
		cDetails.setMaritalStatus(details.getMaritalStatus());
		cDetails.setMobile_Number(details.getMobile_Number());
		cDetails.setPhone_Number(details.getPhone_Number());
		break;
	}

	mop.put("custDetails", cDetails);
	
	List<LoanProgramsOffered> loanDetails= loanService.getLoanDetailsByName(loanName);
	mop.put("loanDetails", loanDetails);
	List<LoanApplication> loanList=LAPService.getLoanApplied(userId);
	mop.put("loanApplied", loanList);
	List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
	mop.put("loanOffered", list);
	return "customer";
}

//DISPLAYING APPLY LOAN PAGE
@RequestMapping(value="apply",method=RequestMethod.POST)
public String applyLoan(@ModelAttribute("my") Users users,@ModelAttribute("offered")LoanProgramsOffered loanProgramOffered,@ModelAttribute("app") LoanApplication application, Map<String,Object> mop){
	mop.put("userId", userId);
	mop.put("date", LocalDate.now());
	mop.put("loanDetails", loanProgramOffered);
	return "applyLoan";

}

//APPLY LOAN FOR CUSTOMER
@RequestMapping(value="applyDetailsLoan",method=RequestMethod.POST)
public String applyDetailsLoan(@ModelAttribute("app") LoanApplication application, Map<String,Object> mop,@ModelAttribute("my") Users use){
	application.setStatus("ACCEPTED");
	application.setDateOfInterview("NOT YET SET");
	LAPService.insertLoanApplicationDetails(application);
	
	CustomerDetails cDetails=new CustomerDetails();

	mop.put("userName", userId);
	List<CustomerDetails> customerDetails=LAPService.selectAllCustomerDetails(userId);
	for( CustomerDetails details:customerDetails){
		cDetails.setApplicant_Id(details.getApplicant_Id());
		cDetails.setApplicant_Name(details.getApplicant_Name());
		cDetails.setCountOfDependents(details.getCountOfDependents());
		cDetails.setDateOfBirth(details.getDateOfBirth());
		cDetails.setEmail_Id(details.getEmail_Id());
		cDetails.setLogin_Id(details.getLogin_Id());
		cDetails.setMaritalStatus(details.getMaritalStatus());
		cDetails.setMobile_Number(details.getMobile_Number());
		cDetails.setPhone_Number(details.getPhone_Number());
		break;
	}

	mop.put("custDetails", cDetails);
	List<LoanApplication> loanList=LAPService.getLoanApplied(userId);
	mop.put("loanApplied", loanList);
	List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
	mop.put("loanOffered", list);
	
	return "customer";
}


//FOR DISPLAYING DETAILS OF CUSTOMER IN LAD AND CUSTOMER
@RequestMapping(value="viewDetailsLAD",method=RequestMethod.GET)
public String viewDetailsLADCust(@RequestParam("id") Long applId,Map<String,Object> mop){
	List<LoanApplication> applications=LAPService.displayStatus(applId);
	String logInId = null;
	String progName=null;
	mop.put("loanDetailsApp", applications);
	for(LoanApplication loanApplication:applications){
		logInId=loanApplication.getLogin_Id();
		progName=loanApplication.getLoanProgram();
	}
	List<LoanProgramsOffered> offereds=loanService.getLoanDetailsByName(progName);
	mop.put("loanDetails", offereds);
	List<CustomerDetails> customerDetails=LAPService.selectAllCustomerDetails(logInId);
	CustomerDetails cDetails=new CustomerDetails();
	for( CustomerDetails details:customerDetails){
		cDetails.setApplicant_Id(details.getApplicant_Id());
		cDetails.setApplicant_Name(details.getApplicant_Name());
		cDetails.setCountOfDependents(details.getCountOfDependents());
		cDetails.setDateOfBirth(details.getDateOfBirth());
		cDetails.setEmail_Id(details.getEmail_Id());
		cDetails.setLogin_Id(details.getLogin_Id());
		cDetails.setMaritalStatus(details.getMaritalStatus());
		cDetails.setMobile_Number(details.getMobile_Number());
		cDetails.setPhone_Number(details.getPhone_Number());
		break;
	}

	mop.put("custDetails", cDetails);
	return "viewDetailsLAD";
}

//FOR SETTING INTERVIEW DATE
@RequestMapping(value="setInterview",method=RequestMethod.POST)
public String setInterViewDate(@RequestParam("id") long id,@RequestParam("dateOfInterview") Date interviewDate,@ModelAttribute("setDate") LoanApplication application,Map<String, 
		Object> model ,@ModelAttribute("my") Users user,@ModelAttribute("loanProg") 
LoanProgramsOffered loanProgramsOffered){
	String date=interviewDate.toString();
	LAPService.setInterviewDate(id,date);
	List<LoanProgramsOffered> list=LAPService.getAllLoanProgramOfferedName();
	/*model.put("loanOffered", loanOffered);*/
	List<LoanApplication> loanApplications=LAPService.getPendingResquest();
	model.put("loanOffered",list);
	model.put("pending", loanApplications);
	if(loanApplications.isEmpty()){
		model.put("notAvail", true);
	}else{
		model.put("notAvail", false);
	}
	return "lad";
}

//SHOWING THE APPROVE OR REJECT LOAN PAGE
@RequestMapping(value="approveOrRejectLoan",method=RequestMethod.GET)
public String approveOrRejectLoan(@ModelAttribute("approveReject") LoanApplication value ,Map<String, Object> model ){
	List<LoanApplication> loanApplications=LAPService.getDetailsOfInterview();
	model.put("details", loanApplications);
	return "approveOrRejectLoan";
}

//FOR REJECTING LOAN
@RequestMapping(value="reject",method=RequestMethod.POST)
public String rejectLoan(Map<String, Object> model ,@ModelAttribute("approveReject") LoanApplication value ,@RequestParam("id") long id){
	LAPService.setReject(id);
	List<LoanApplication> loanApplications=LAPService.getDetailsOfInterview();
	model.put("details", loanApplications);
	return "approveOrRejectLoan";
}


//FOR VIEWING LOANS FOR APPROVING OR REJECTED
@RequestMapping(value="selectLoan",method=RequestMethod.GET)
public String approveLoan(@ModelAttribute("approveReject") LoanApplication value ,Map<String, Object> model ,@RequestParam("id") long id){
	boolean status=true;
	idForUpdate=id;
	String userIdS = null;
	String loanName=null;
	double amount=0,rateOfInterest=0;
	model.put("id", id);
	
	List<LoanApplication> applications= LAPService.displayStatus(id);
	model.put("loanApp", applications);
	for(LoanApplication loanApplication:applications){
		userIdS=loanApplication.getLogin_Id();
		loanName=loanApplication.getLoanProgram();
		amount=loanApplication.getAmountOfLoan();
		
	}
	CustomerDetails cDetails=new CustomerDetails();
	List<CustomerDetails> customerDetails=LAPService.selectAllById(userIdS);
	for( CustomerDetails details:customerDetails){
		cDetails.setApplicant_Id(details.getApplicant_Id());
		cDetails.setApplicant_Name(details.getApplicant_Name());
		applicantName=details.getApplicant_Name();
		cDetails.setCountOfDependents(details.getCountOfDependents());
		cDetails.setDateOfBirth(details.getDateOfBirth());
		cDetails.setEmail_Id(details.getEmail_Id());
		cDetails.setLogin_Id(details.getLogin_Id());
		cDetails.setMaritalStatus(details.getMaritalStatus());
		cDetails.setMobile_Number(details.getMobile_Number());
		cDetails.setPhone_Number(details.getPhone_Number());
		break;
	}
	
	List<LoanProgramsOffered> loanProgramsOffereds=loanService.getLoanDetailsByName(loanName);
	
	approvedLoans=new ApprovedLoans();
	for(LoanProgramsOffered offered:loanProgramsOffereds){
		approvedLoans.setCustomer_name(applicantName);
		approvedLoans.setAmountOfLoanGranted(amount);
		approvedLoans.setApplication_id(id);
		approvedLoans.setDownpayment(amount*10/100);
		approvedLoans.setRateOfInterest(offered.getRateOfInterest());
		approvedLoans.setYearsTimePeriod((float)offered.getDurationInYears());
		double si=amount*offered.getDurationInYears()*offered.getRateOfInterest()/100;
		approvedLoans.setMonthlyInstallment(((amount+si-(amount*10/100))/offered.getDurationInYears())/12);
		approvedLoans.setTotalAmountPayable(amount+si);
	}
	model.put("approvedLoans", approvedLoans);
	model.put("custDetails", cDetails);
	return "approveLoanDetails";
}

//FOR APPROVE LOAN
@RequestMapping(value="approve",method=RequestMethod.POST)
public String approveLoan(Map<String, Object> model ,@ModelAttribute("approveReject") ApprovedLoans value ,@RequestParam("id") long id){
	LAPService.setApprove(idForUpdate);
	LAPService.insertApprovedLoan(approvedLoans);
	List<LoanApplication> loanApplications=LAPService.getDetailsOfInterview();
	model.put("details", loanApplications);
	return "approveOrRejectLoan";
}

@RequestMapping(value="reset",method=RequestMethod.GET)
public String resetLogin(){
	return "login";
}

//HOMEPAGE
@RequestMapping(value="homepagere",method=RequestMethod.GET)
public String homepage(){
	return "homepage";
}

//LOGOUT CUSTOMER
@RequestMapping(value="logoutCust",method=RequestMethod.POST)
public String logoutCust(@ModelAttribute("my") Users users){
	return "login";
}
}
