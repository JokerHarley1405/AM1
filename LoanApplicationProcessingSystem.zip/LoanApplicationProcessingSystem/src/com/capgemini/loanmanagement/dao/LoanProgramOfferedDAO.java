package com.capgemini.loanmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;




@Repository("loanDao")
public class LoanProgramOfferedDAO implements ILoanProgramOfferdDao {
	
	@PersistenceContext
	EntityManager entitymanager;
	


	/* (non-Javadoc)
	 * @see com.cg.LMS.DAO.ILoanProgramOfferdDao#addTrainee(com.cg.LMS.bean.LoanProgramOffered)
	 */
	@Override
	public void addLoanProgram(LoanProgramsOffered loanProgramOffered) {
		entitymanager.persist(loanProgramOffered);
		
	}
	@Override
	public List<LoanProgramsOffered> getLoanDetails(){
		Query query = entitymanager.createQuery("FROM LoanProgramsOffered");
		List<LoanProgramsOffered> list=query.getResultList();
		return list;
	}
public List<LoanProgramsOffered> getLoanDetailsByName(String loanName){
	Query query=entitymanager.createQuery("FROM LoanProgramsOffered where programName =:loanName");
	query.setParameter("loanName", loanName);
	List<LoanProgramsOffered> list=query.getResultList();
	return list;	
}

public void updateLoanProgram(LoanProgramsOffered loanProgramOffered){
	Query query=entitymanager.createQuery("update LoanProgramsOffered set description=:description,type=:type,durationInYears=:years,minLoanAmount=:minAmount,maxLoanAmount=:maxAmount,rateOfInterest=:rate,proofsRequired=:proofs where programName =:name");	
	query.setParameter("name", loanProgramOffered.getProgramName());
	query.setParameter("description", loanProgramOffered.getDescription());

	query.setParameter("type", loanProgramOffered.getType());

	query.setParameter("years", loanProgramOffered.getDurationInYears());

	query.setParameter("minAmount", loanProgramOffered.getMinLoanAmount());
	query.setParameter("maxAmount", loanProgramOffered.getMaxLoanAmount());
	query.setParameter("rate", loanProgramOffered.getRateOfInterest());
	query.setParameter("proofs", loanProgramOffered.getProofsRequired());

	query.executeUpdate();
}
@Override
public void deleteLoanProgram(String name) {
	Query query=entitymanager.createQuery("delete FROM LoanProgramsOffered where programName =:name");	
	query.setParameter("name", name);
	query.executeUpdate();
	}
	


public List<LoanApplication> getLoanApplicationDetails(){
	Query query = entitymanager.createQuery("FROM LoanApplication");
	List<LoanApplication> list1=query.getResultList();
	return list1;
	}

public List<LoanApplication> getLoanApplicationStatus(String Status){
	Query query=entitymanager.createQuery("FROM LoanApplication WHERE status=:status");
	query.setParameter("status", Status);
	List<LoanApplication> list1=query.getResultList();
	return list1;
}


}
