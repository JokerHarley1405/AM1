package com.capgemini.loanmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.loanmanagement.bean.ApprovedLoans;
import com.capgemini.loanmanagement.bean.CustomerDetails;
import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;
import com.capgemini.loanmanagement.bean.Users;


@Repository("LAPDao")
public class LAPDaoImpl implements ILAPDao{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Users> getDetailsListUsers(Users user) {
		Query query = entityManager.createQuery("FROM Users where login_Id =:myId and password=:myPass ");
		query.setParameter("myId", user.getLogin_Id());
		query.setParameter("myPass", user.getPassword());
		
		List<Users> myData = query.getResultList();
		return myData;
		
	}

	@Override
	public List<LoanProgramsOffered> getAllLoanProgramOfferedName() {
		Query query = entityManager.createQuery("FROM LoanProgramsOffered");
		List<LoanProgramsOffered> programsName = query.getResultList();
		return programsName;
	}

	@Override
	public List<LoanApplication> displayStatus(long id) {
		Query query = entityManager.createQuery("FROM LoanApplication where applicationId =:AppId");
		query.setParameter("AppId", id);
		List<LoanApplication> myData=query.getResultList();
		return myData;
	}

	@Override
	public void insertCustomerDetails(CustomerDetails custDetails) {
		 
		entityManager.persist(custDetails);
		
	}

	@Override
	public void insertUserDetails(Users user) {
		 
		entityManager.persist(user);
	}

	@Override
	public List<CustomerDetails> selectAllCustomerDetails(String string) {
		 
		Query query = entityManager.createQuery("FROM CustomerDetails where login_Id='"+string+"'");
		List<CustomerDetails> myData=query.getResultList();
		return myData;
	}

	@Override
	public void insertLoanApplicationDetails(LoanApplication application) {
		 
		entityManager.persist(application);
	}

	@Override
	public List<LoanApplication> getLoanApplied(String string) {
		 
		Query query = entityManager.createQuery("FROM LoanApplication where login_Id='"+string+"'");
		List<LoanApplication> myData=query.getResultList();
		return myData;
	}

	@Override
	public List<LoanApplication> getPendingResquest() {
		 
		Query query = entityManager.createQuery("FROM LoanApplication where status='ACCEPTED' and dateOfInterview='NOT YET SET'");
		List<LoanApplication> myData=query.getResultList();
		return myData;
	}

	@Override
	public void setInterviewDate(long id, String date) {
		 
		Query query=entityManager.createQuery("update LoanApplication set dateOfInterview=:dateInter where applicationId=:appid");
		query.setParameter("dateInter", date);
		query.setParameter("appid", id);
		int rows=query.executeUpdate();
	
		
	}

	@Override
	public List<LoanApplication> getDetailsOfInterview() {
		 
		Query query = entityManager.createQuery("FROM LoanApplication where status='ACCEPTED' and dateOfInterview!='NOT YET SET'");
		List<LoanApplication> myData=query.getResultList();
		return myData;
	}

	@Override
	public void setReject(long id) {
		 
		Query query=entityManager.createQuery("update LoanApplication set status='REJECTED' where applicationId=:appid");

		query.setParameter("appid", id);
		int rows=query.executeUpdate();
	}

	@Override
	public List<CustomerDetails> selectAllById(String userId) {
		 
		Query query = entityManager.createQuery("FROM CustomerDetails where login_Id=:myId");
		query.setParameter("myId", userId);
		List<CustomerDetails> myData=query.getResultList();
		return myData;
	}

	@Override
	public void setApprove(long id) {
		 
		Query query=entityManager.createQuery("update LoanApplication set status='APPROVED' where applicationId=:appid");

		query.setParameter("appid", id);
		int rows=query.executeUpdate();
	}

	@Override
	public void insertApprovedLoan(ApprovedLoans approvedLoans) {
		 
		entityManager.persist(approvedLoans);
	}

	@Override
	public List<ApprovedLoans> showApproved(long id) {
		 
		Query query = entityManager.createQuery("FROM ApprovedLoans where application_id=:myId");
		query.setParameter("myId", id);
		List<ApprovedLoans> myData=query.getResultList();
		return myData;
	}

	@Override
	public boolean getCustomerName(String name) {
		 
		Query query = entityManager.createQuery("FROM Users where login_Id=:myId");
		query.setParameter("myId", name);
		List<ApprovedLoans> myData=query.getResultList();
		if(myData.isEmpty()){
			return true;
		}
		return false;
	}


	
}
