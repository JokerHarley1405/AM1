package com.capgemini.loanmanagement.dao;

import java.util.List;

import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;


public interface ILoanProgramOfferdDao {

	public abstract void addLoanProgram(LoanProgramsOffered loanProgramOffered);
	public abstract List<LoanProgramsOffered> getLoanDetails();
	public abstract List<LoanProgramsOffered> getLoanDetailsByName(String loanName);
	public abstract void updateLoanProgram(LoanProgramsOffered loanProgramOffered);
	public abstract void deleteLoanProgram(String  name);
	public List<LoanApplication> getLoanApplicationDetails();
	public List<LoanApplication> getLoanApplicationStatus(String Status);
	
} 