package com.capgemini.loanmanagement.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LoanProgramsOffered")
public class LoanProgramsOffered implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="PROGRAMNAME")
	private String programName;
	@Column(name="DESCRIPTION")
	private String description;
	@Column(name="TYPE")
	private String type;
	@Column(name="MINLOANAMOUNT")
	private double minLoanAmount;
	@Column(name="MAXLOANAMOUNT")
	private double maxLoanAmount;
	@Column(name="RATEOFINTEREST")
	private float rateOfInterest;
	@Column(name="PROOFSREQUIRED")
	private String proofsRequired;
	@Column(name="DURATIONINYEARS")
	private double durationInYears;
	public double getDurationInYears() {
		return durationInYears;
	}
	public void setDurationInYears(double durationInYears) {
		this.durationInYears = durationInYears;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getMinLoanAmount() {
		return minLoanAmount;
	}
	public void setMinLoanAmount(double minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}
	public double getMaxLoanAmount() {
		return maxLoanAmount;
	}
	public void setMaxLoanAmount(double maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}
	public float getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public String getProofsRequired() {
		return proofsRequired;
	}
	public void setProofsRequired(String proofsRequired) {
		this.proofsRequired = proofsRequired;
	}
	@Override
	public String toString() {
		return "LoanProgramsOffered [programName=" + programName
				+ ", description=" + description + ", type=" + type
				+ ", minLoanAmount=" + minLoanAmount + ", maxLoanAmount="
				+ maxLoanAmount + ", rateOfInterest=" + rateOfInterest
				+ ", proofsRequired=" + proofsRequired + "]";
	}
	
	
}
