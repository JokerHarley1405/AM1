package com.capgemini.loanmanagement.bean;

import java.io.Serializable;
import java.sql.Date;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMERDETAILS")
public class CustomerDetails implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="appseq")
	@SequenceGenerator(name="appseq",sequenceName="seq_applicant_id")
	@Column(name="APPLICANT_ID")
	private long applicant_Id;
	@Column(name="APPLICANT_NAME")
	private String applicant_Name;
	@Column(name="DATE_OF_BIRTH")
	private Date dateOfBirth;
	@Column(name="MARITAL_STATUS")
	private String maritalStatus;
	@Column(name="PHONE_NUMBER")
	private Long phone_Number;
	@Column(name="MOBILE_NUMBER")
	private Long mobile_Number;
	@Column(name="COUNTOFDEPENDENTS")
	private Short countOfDependents;
	@Column(name="EMAIL_ID")
	private String email_Id;
	@Column(name="LOGIN_ID")
	private String login_Id;
	public long getApplicant_Id() {
		return applicant_Id;
	}
	public void setApplicant_Id(long applicant_Id) {
		this.applicant_Id = applicant_Id;
	}
	public String getApplicant_Name() {
		return applicant_Name;
	}
	public void setApplicant_Name(String applicant_Name) {
		this.applicant_Name = applicant_Name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public Long getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(Long phone_Number) {
		this.phone_Number = phone_Number;
	}
	public Long getMobile_Number() {
		return mobile_Number;
	}
	public void setMobile_Number(Long mobile_Number) {
		this.mobile_Number = mobile_Number;
	}
	public Short getCountOfDependents() {
		return countOfDependents;
	}
	public void setCountOfDependents(Short countOfDependents) {
		this.countOfDependents = countOfDependents;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getLogin_Id() {
		return login_Id;
	}
	public void setLogin_Id(String login_Id) {
		this.login_Id = login_Id;
	}
	
	
}
