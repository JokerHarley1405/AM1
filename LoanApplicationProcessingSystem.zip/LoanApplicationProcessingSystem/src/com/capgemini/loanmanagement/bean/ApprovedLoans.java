package com.capgemini.loanmanagement.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="APPROVEDLOANS")
public class ApprovedLoans implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="APPLICATION_ID")
	private long application_id;
	@Column(name="CUSTOMER_NAME")
	private String customer_name;
	@Column(name="AMOUNTOFLOANGRANTED")
	private double amountOfLoanGranted;
	@Column(name="MONTHLYINSTALLMENT")
	private double monthlyInstallment;
	@Column(name="YEARSTIMEPERIOD")
	private float yearsTimePeriod;
	@Column(name="DOWNPAYMENT")
	private double downpayment;
	@Column(name="RATEOFINTEREST")
	private float rateOfInterest;
	@Column(name="TOTALAMOUNTPAYABLE")
	private double totalAmountPayable;
	
	@Override
	public String toString() {
		return "ApprovedLoans [application_id=" + application_id
				+ ", customer_name=" + customer_name + ", amountOfLoanGranted="
				+ amountOfLoanGranted + ", monthlyInstallment="
				+ monthlyInstallment + ", yearsTimePeriod=" + yearsTimePeriod
				+ ", downpayment=" + downpayment + ", rateOfInterest="
				+ rateOfInterest + ", totalAmountPayable=" + totalAmountPayable
				+ "]";
	}
	public float getYearsTimePeriod() {
		return yearsTimePeriod;
	}
	public void setYearsTimePeriod(float yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}
	public double getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}
	public void setAmountOfLoanGranted(double amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}
	public long getApplication_id() {
		return application_id;
	}
	public void setApplication_id(long application_id) {
		this.application_id = application_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	public void setMonthlyInstallment(double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}

	public double getDownpayment() {
		return downpayment;
	}
	public void setDownpayment(double downpayment) {
		this.downpayment = downpayment;
	}
	public float getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public double getTotalAmountPayable() {
		return totalAmountPayable;
	}
	public void setTotalAmountPayable(double totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}


	
	
}
