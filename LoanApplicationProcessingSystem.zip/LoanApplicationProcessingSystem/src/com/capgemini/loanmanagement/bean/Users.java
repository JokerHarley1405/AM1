package com.capgemini.loanmanagement.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="USERS")
public class Users implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="login_Id")
	@NotEmpty(message="Username should not be empty")
	private String login_Id;
	@Column(name="password")
	@NotEmpty(message="Password should not be empty")
	private String password;
	
		
	@Column(name="role")
	private String role;
	
	
	@Override
	public String toString() {
		return "Users [login_Id=" + login_Id + ", password=" + password
				+ ", role=" + role + "]";
	}
	public String getLogin_Id() {
		return login_Id;
	}
	public void setLogin_Id(String login_Id) {
		this.login_Id = login_Id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}


}