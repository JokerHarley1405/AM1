package com.capgemini.loanmanagement.service;

import java.util.List;

import com.capgemini.loanmanagement.bean.ApprovedLoans;
import com.capgemini.loanmanagement.bean.CustomerDetails;
import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;
import com.capgemini.loanmanagement.bean.Users;

public interface ILAPService {

	public abstract List<Users> getDetailsListUsers(Users user);

	public abstract List<LoanProgramsOffered> getAllLoanProgramOfferedName();

	public abstract List<LoanApplication> displayStatus(long id);

	public abstract void insertUserDetails(Users user);

	public abstract void insertCustomerDetails(CustomerDetails custDetails);

	public abstract List<CustomerDetails> selectAllCustomerDetails(String string);

	public abstract void insertLoanApplicationDetails(
			LoanApplication application);

	public abstract List<LoanApplication> getLoanApplied(String string);

	public abstract List<LoanApplication> getPendingResquest();

	public abstract void setInterviewDate(long id, String date);

	public abstract List<LoanApplication> getDetailsOfInterview();


	public abstract void setReject(long id);

	public abstract List<CustomerDetails> selectAllById(String userId);

	public abstract void setApprove(long id);

	public abstract void insertApprovedLoan(ApprovedLoans approvedLoans);

	public abstract List<ApprovedLoans> showApproved(long id);

	public abstract boolean getCustomerName(String name);

	
	
}
