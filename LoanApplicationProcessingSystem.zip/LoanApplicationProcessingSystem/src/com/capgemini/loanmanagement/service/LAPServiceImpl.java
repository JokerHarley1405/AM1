package com.capgemini.loanmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.loanmanagement.bean.ApprovedLoans;
import com.capgemini.loanmanagement.bean.CustomerDetails;
import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;
import com.capgemini.loanmanagement.bean.Users;
import com.capgemini.loanmanagement.dao.ILAPDao;



@Service("LAPService")
@Transactional
public class LAPServiceImpl implements ILAPService{

	@Autowired
	ILAPDao LAPDao ;

	@Override
	public List<Users> getDetailsListUsers(Users user) {
		// TODO Auto-generated method stub
		return LAPDao.getDetailsListUsers(user);
	}

	@Override
	public List<LoanProgramsOffered> getAllLoanProgramOfferedName() {
		// TODO Auto-generated method stub
		return LAPDao.getAllLoanProgramOfferedName();
	}

	@Override
	public List<LoanApplication> displayStatus(long id) {
		// TODO Auto-generated method stub
		return LAPDao.displayStatus(id);
	}

	@Override
	public void insertCustomerDetails(CustomerDetails custDetails) {
		// TODO Auto-generated method stub
		 LAPDao.insertCustomerDetails(custDetails);
	}

	@Override
	public void insertUserDetails(Users user) {
		// TODO Auto-generated method stub
		 LAPDao.insertUserDetails(user);
	}

	@Override
	public List<CustomerDetails> selectAllCustomerDetails(String string) {
		// TODO Auto-generated method stub
		return LAPDao.selectAllCustomerDetails(string);
	}

	@Override
	public void insertLoanApplicationDetails(LoanApplication application) {
		// TODO Auto-generated method stub
		LAPDao.insertLoanApplicationDetails(application);
	}

	@Override
	public List<LoanApplication> getLoanApplied(String string) {
		// TODO Auto-generated method stub
		return LAPDao.getLoanApplied(string);
	}

	@Override
	public List<LoanApplication> getPendingResquest() {
		// TODO Auto-generated method stub
		return LAPDao.getPendingResquest();
	}

	@Override
	public void setInterviewDate(long id, String date) {
		// TODO Auto-generated method stub
		LAPDao.setInterviewDate(id,date);
	}

	@Override
	public List<LoanApplication> getDetailsOfInterview() {
		// TODO Auto-generated method stub
		return LAPDao.getDetailsOfInterview();
	}

	@Override
	public void setReject(long id) {
		// TODO Auto-generated method stub
		LAPDao.setReject(id);
	}

	@Override
	public List<CustomerDetails> selectAllById(String userId) {
		// TODO Auto-generated method stub
		return LAPDao.selectAllById(userId);
	}

	@Override
	public void setApprove(long id) {
		// TODO Auto-generated method stub
		LAPDao.setApprove(id);
	}

	@Override
	public void insertApprovedLoan(ApprovedLoans approvedLoans) {
		// TODO Auto-generated method stub
		LAPDao.insertApprovedLoan(approvedLoans);
	}

	@Override
	public List<ApprovedLoans> showApproved(long id) {
		// TODO Auto-generated method stub
		return LAPDao.showApproved(id);
	}

	@Override
	public boolean getCustomerName(String name) {
		// TODO Auto-generated method stub
		return LAPDao.getCustomerName(name);
	}




	
}
