package com.capgemini.loanmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.loanmanagement.bean.LoanApplication;
import com.capgemini.loanmanagement.bean.LoanProgramsOffered;
import com.capgemini.loanmanagement.dao.ILoanProgramOfferdDao;



@Service("loanService")
@Transactional
public class LoanProgramOfferdService implements ILoanProgramOfferedservice {

	@Autowired
	ILoanProgramOfferdDao loanDao;
	
	/* (non-Javadoc)
	 * @see com.cg.LMS.Service.ILoanProgramOfferedservice#addLoanProgram(com.cg.LMS.bean.LoanProgramOffered)
	 */
	@Override
	public void addLoanProgram(LoanProgramsOffered loanProgramOffered){
		loanDao.addLoanProgram(loanProgramOffered);
	}

	@Override
	public List<LoanProgramsOffered> getLoanDetails() {
		// TODO Auto-generated method stub
		return loanDao.getLoanDetails();
	}

	@Override
	public List<LoanProgramsOffered> getLoanDetailsByName(String loanName) {
		// TODO Auto-generated method stub
		return loanDao.getLoanDetailsByName(loanName);
	}

	@Override
	public void updateLoanProgram(LoanProgramsOffered loanProgramOffered) {
		// TODO Auto-generated method stub
		loanDao.updateLoanProgram(loanProgramOffered);
	}

	@Override
	public void deleteLoanProgram(String name) {

		loanDao.deleteLoanProgram(name);
		
	}

	@Override
	public List<LoanApplication> getLoanApplicationDetails() {
		// TODO Auto-generated method stub
		return loanDao.getLoanApplicationDetails();
	}

	@Override
	public List<LoanApplication> getLoanApplicationStatus(String Status) {
		// TODO Auto-generated method stub
		return loanDao.getLoanApplicationStatus(Status);
	}

	

	
	
}
