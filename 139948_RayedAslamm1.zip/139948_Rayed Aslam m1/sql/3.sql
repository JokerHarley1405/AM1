create database mtest1;

--3.1.1

	--creating table Student
create table Student
(RollNo numeric(4,0) PRIMARY KEY, StudentName varchar(30), Stream varchar (15)
CONSTRAINT stram_Check CHECK (Stream IN('Arts','Commerce','Science')))
;

	--inserting values into Student table
INSERT INTO Student values 
(1001,'Anil','Science'),
(1002,'Madhavi','Arts'),
(1003,'Ramos','Commerce'),
(1004,'Theo','Arts'),
(1005,'Ronaldo','Science')
;

select * from Student;

--3.1.2

	--creating table Marks
create table Marks
(
RollNo numeric(4,0), Subject1 int, Subject2 int,Subject3 int,
Subject4 int, Subject5 int, Total int,
FOREIGN KEY(RollNo) REFERENCES Student(RollNo)
)
;


	--inserting values into Marks table
insert into Marks values
(1002,35,40,35,45,37,192),
(1001,100,50,50,50,50,300),
(1003,80,50,65,90,75,360),
(1004,60,55,65,60,55,295),
(1005,90,90,90,90,90,450)
;

select * from marks;

--3.2.1

	--printing data of Student onto the console
SELECT * FROM Student;

--3.2.2

	--printing marks of student whose rollno is 1004
SELECT * FROM Marks
WHERE RollNo = 1004
;

--3.2.3

	--printing details of students who have 'h' in their name 
SELECT StudentName, Subject1, Subject2, Subject3, Subject4, Subject5
FROM Student s join Marks m ON s.RollNo = m.RollNo
WHERE StudentName LIKE '%h%'
;

--3.2.4

	--creating a procedure to insert values into the Marks table
GO
CREATE PROC addMarks
(@rollNo varchar(30), @sub1 int, @sub2 int, @sub3 int, @sub4 int, @sub5 int)
AS
BEGIN
	BEGIN TRY
		INSERT INTO Marks VALUES
		(@rollno,@sub1,@sub2,@sub3,@sub4,@sub5,(@sub1+@sub2+@sub3+@sub4+@sub5)
		);
	END TRY
	BEGIN CATCH
	PRINT ERROR_MESSAGE();
	END CATCH
END

GO
exec addMarks 1005,34,53,54,65,64;

select * from marks
delete from marks where Subject1=34;



