//function to calculate Grade and display the required details
function calcGrade()
{
	//storing values of marks of student from the form
	var mark1 = document.getElementById("sub1").value;
	var mark2 = document.getElementById("sub2").value;
	var mark3 = document.getElementById("sub3").value;
	var mark4 = document.getElementById("sub4").value;
	var mark5 = document.getElementById("sub5").value;
	//calculating the total marks of all subjects into the variable totalMark
	var totalMark = parseInt(mark1) + parseInt(mark2) + parseInt(mark3) + parseInt(mark4) + parseInt(mark5);
	//alert(totalMark);
	//calculating the percentage of total marks of all subjects into the variable perMarks
	var perMarks = (parseInt(totalMark) / 500) * 100;
	var grade;  //grade variable to calculate and display the grade
	//calculating grade according to the percent obtained by the student
	if (perMarks >= 80)
	{ grade = "A+"; }
	else if (perMarks < 80 && perMarks >=70)
	{ grade = "A"; }
	else if (perMarks < 70 && perMarks >=60)
	{ grade = "B+"; }
	else if (perMarks < 60 && perMarks >=50)
	{ grade = "B"; }
	else if (perMarks < 50)
	{ grade = "C"; }
	//alert(grade);
	//displaying the required details in an alert box after the validation is complete
	alert("Total Marks obtained by student: "+totalMark+"\n"+
	"Percentage of marks obtained by student: "+perMarks+"%\n"+
	"Grade of student: "+grade);
	}