package com.cg.LMS.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import com.cg.LMS.dto.CustomerDetailsBean;
import com.cg.LMS.dto.LoanApplicationBean;
import com.cg.LMS.dto.LoanProgramBean;
import com.cg.LMS.dto.UserBean;
import com.cg.LMS.exception.LMSException;
import com.cg.LMS.service.LMSService;
import com.cg.LMS.service.LMSServiceImpl;


public class LMSMain {
	public static void main(String[] args) {
		LMSService service= new LMSServiceImpl();
		Scanner sc=new Scanner(System.in);
		do {
			System.out.println("\nChoose below Option for Funcationality\n"
					+ "1. To View All Loan Program \n"
					+ "2. To Login (For Admin/LAD) \n"
					+ "3. To check Your Application Status\n"
					+ "4. To Exit From Application");
			int option = sc.nextInt();
			switch (option) {
			case 1:
				List<LoanProgramBean> list = null;
				try {
					System.out.println("inside Main method");
					list = service.viewAllLoans();
					System.out.println(list.size());
				} catch (LMSException e2) {
					System.out.println("Error");
					e2.printStackTrace();
				}

				for (LoanProgramBean loanProgramBean : list) {
					System.out.println("ProgramName :"
							+ loanProgramBean.getProgramName());
					System.out.println("\ndescription  :"
							+ loanProgramBean.getDescription());
					System.out.println("\ntype :" + loanProgramBean.getType());
					System.out.println("\ndurationinyears :"
							+ loanProgramBean.getDurationInYears());
					System.out.println("\nminloanamount :"
							+ loanProgramBean.getMinLoanAmount());
					System.out.println("\nmaxloanamount :"
							+ loanProgramBean.getMaxLoanAmount());
					System.out.println("\nrateofinterest :"
							+ loanProgramBean.getRateOfInterest());
					System.out.println("\nproofs_required :"
							+ loanProgramBean.getProofsRequired());
				}

				System.out.println("Do You wish to Apply For Loan Yes or No??");

				String choice = sc.next();
				if (choice.equals("Yes")) {
					do {

						System.out.println("Enter Loan program Name");
						String programName = sc.next();
						boolean checkProgramName = service.validateProgramName(programName);

						//have to create this method in DaoImpl to check weather entered name exist in offer programmed list or not  

						if (checkProgramName == true) {
							System.out.println("Enter Loan Application Details\n___________________________________");
							
							do {
								LoanApplicationBean loan = new LoanApplicationBean();
								
								loan.setLoanProgram(programName);
								
								System.out.println("Enter Address Of Property");
								loan.setAddressOfProperty(sc.next());
								
								System.out.println("Enter Loan Amount");
								loan.setAmountOfLoan(sc.nextLong());
								
								System.out.println("Enter Annual Family Income");
								loan.setAnnualFamilyIncome(sc.nextLong());
								
								System.out.println("Enter Document Proofs Available");
								loan.setDocumentProofsAvailable(sc.next());
								
								System.out.println("Enter Guarantee Cover");
								loan.setGuaranteeCover(sc.next());
								
								System.out.println("Enter Market Value Of GuaranteeCover");
								loan.setMarketValueofGuaranteeCover(sc.nextLong());
								
								try {
									boolean checkLoan=service.validateLoanApplication(loan);
									
									if(checkLoan==true)
										break;
									else
										throw new LMSException();
								} catch (LMSException e) {
									System.out.println("Invalid Loan Details\nRe-enter Loan Details"+e.getMessage());
								}
							}while (true);
							}else {
							System.out.println("Enter Valid Program Name");
						}
					}while (true);
				}
				break;

			//case 2 main switch starts here	
			case 2:
				UserBean user = new UserBean();
				String role = "";

				System.out.println("Enter Your Login ID");
				user.setLoginID(sc.next());

				System.out.println("Enter Your Password");
				user.setPassword(sc.next());

				try {
					role = service.validateUser(user);
					if (role.equals("")) {
						throw new LMSException();
					} else
						user.setRole(role);
				} catch (LMSException e1) {
					// TODO Auto-generated catch block
					System.out.println("Login Id or password is incorrect");
				}

				if (role.equals("admin")) {
					System.out.println("Welcome To Admin Page\n"
							+ "Enter\n1 to view All Application\n"
							+ "2 to add Loan Programe\n"
							+ "3 to Update Loan Programe\n"
							+ "4 to Remove Loan Programe");
					int adminChoice = sc.nextInt();
					switch (adminChoice) {
					case 1:
						System.out.println("Enter Loan Progame name");
						String programeName = sc.next();

						System.out.println("Enter Loan Application Status");
						String loanStatus = sc.next();

						try {
							List<LoanApplicationBean> loanList = service
									.loanProgList(loanStatus, programeName);
							for (LoanApplicationBean loanApplicationBean : loanList) {
								System.out.println("Application ID : "
										+ loanApplicationBean
												.getApplicationID());
								System.out.println("Loan Program \n"
										+ loanApplicationBean.getLoanProgram());
								System.out
										.println("Amount Of Loan \n"
												+ loanApplicationBean
														.getAmountOfLoan());
								System.out.println("Address Of Property \n"
										+ loanApplicationBean
												.getAddressOfProperty());
								System.out.println("Annual Family Income \n"
										+ loanApplicationBean
												.getAnnualFamilyIncome());
								System.out
										.println("Document Proofs Available \n"
												+ loanApplicationBean
														.getDocumentProofsAvailable());
								System.out.println("Guarantee Cover \n"
										+ loanApplicationBean
												.getGuaranteeCover());
								System.out
										.println("Market Value of GuaranteeCover \n"
												+ loanApplicationBean
														.getMarketValueofGuaranteeCover());
								System.out.println("status \n"
										+ loanApplicationBean.getStatus());
								System.out.println("Date Of Interview \n"
										+ loanApplicationBean
												.getDateOfInterview());
							}
						} catch (LMSException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						break;

					case 2:
						LoanProgramBean loanPrograme = new LoanProgramBean();

						System.out.println("Enter ProgramName :");
						loanPrograme.setProgramName(sc.next());

						System.out.println("\nEnter Description  :");
						loanPrograme.setDescription(sc.next());

						System.out.println("\nEnter loan type :");
						loanPrograme.setType(sc.next());

						System.out.println("\nEnter duration in years :");
						loanPrograme.setDurationInYears(sc.nextInt());

						System.out.println("\nEnter min loan amount :");
						loanPrograme.setMinLoanAmount(sc.nextLong());

						System.out.println("\nEnter max loan amount :");
						loanPrograme.setMaxLoanAmount(sc.nextLong());

						System.out.println("\nEnter rate of interest :");
						loanPrograme.setRateOfInterest(sc.nextFloat());

						System.out.println("\nEnter proofs required :");
						loanPrograme.setProofsRequired(sc.next());

						boolean checkLoan = false;
						try {
							checkLoan = service.addLoanProg(loanPrograme);
							if (checkLoan == true) {
								System.out
										.println("Inserted loan Successfully ");
							} else {
								throw new LMSException();
							}
						} catch (LMSException e) {
							System.out
									.println("Problem In Inserting Loan programe");
						}
						break;

					case 3:
						do {
							System.out
									.println("Enter Programe name to which you want to update");
							String pName = sc.next();
							boolean checkpName = service
									.validateProgramName(pName);
							//have to create this method in DaoImpl to check weather entered name exist in offer programmed list or not  
							if (checkpName == true) {
								System.out
										.println("Enter Your Choice\n1 to update type\n"
												+ "2 to update durationinyears\n"
												+ "3 to update minloanamount\n"
												+ "4 to update maxloanamount\n"
												+ "5 to update rateofinterest");
								int updateOption = sc.nextInt();

								System.out.println("Enter data to update");
								String updateValue = sc.next();

								boolean checkUpdate = false;
								try {
									checkUpdate = service.updateLoanProg(
											updateOption, pName, updateValue);
								} catch (LMSException e1) {
									// TODO Auto-generated catch block
									System.out
											.println("Problem In updating data in Loan programe");
								}

								try {
									if (checkUpdate == true) {
										System.out
												.println("Updated loan data Successfully ");
									} else {
										throw new LMSException();
									}
								} catch (LMSException e) {
									System.out.println("Data Not updated");
								}
								break;
							} else
								System.out.println("Enter valid Programe Name");
						} while (true);
						break;

					case 4:
						System.out
								.println("Enter Programe Name to delete from database");
						do {
							String deletePrograme = sc.next();
							boolean checkprogName = service
									.validateProgramName(deletePrograme);
							if (checkprogName == true) {

								boolean checkDelete = false;
								try {
									checkDelete = service
											.deleteLoanProg(deletePrograme);
								} catch (LMSException e1) {
									// TODO Auto-generated catch block
									e1.printStackTrace();
								}
								try {
									if (checkDelete == true) {
										System.out
												.println("Deleted loan data Successfully ");
										break;
									} else {
										throw new LMSException();
									}
								} catch (LMSException e) {
									System.out
											.println("Problem In deleting data in Loan programe");
								}
							} else {
								System.out.println("Enter valid program name");
							}
						} while (true);
						break;
					}
				} else if (role.equals("lad")) {
					//lad codes start from here___________________________________________
					System.out.println("Enter\n1 to view application\n"
							+ "2 to change status");
					int ladChoice = sc.nextInt();
					switch (ladChoice) {
					//lad 1st functionality start from here
					case 1:
						do {
							System.out
									.println("Enter Programe Name to View Applications");
							String progName = sc.next();

							boolean checkprogName = service
									.validateProgramName(progName);
							List<LoanApplicationBean> programeList = new ArrayList<>();

							if (checkprogName == true) {
								try {
									programeList = service
											.viewApplList(progName);
									for (LoanApplicationBean loanApplicationBean : programeList) {
										System.out
												.println("\nApplication ID : "
														+ loanApplicationBean
																.getApplicationID());
										System.out.println("Loan Program \n"
												+ loanApplicationBean
														.getLoanProgram());
										System.out.println("Amount Of Loan \n"
												+ loanApplicationBean
														.getAmountOfLoan());
										System.out
												.println("Address Of Property \n"
														+ loanApplicationBean
																.getAddressOfProperty());
										System.out
												.println("Annual Family Income \n"
														+ loanApplicationBean
																.getAnnualFamilyIncome());
										System.out
												.println("Document Proofs Available \n"
														+ loanApplicationBean
																.getDocumentProofsAvailable());
										System.out.println("Guarantee Cover \n"
												+ loanApplicationBean
														.getGuaranteeCover());
										System.out
												.println("Market Value of GuaranteeCover \n"
														+ loanApplicationBean
																.getMarketValueofGuaranteeCover());
										System.out.println("status \n"
												+ loanApplicationBean
														.getStatus());
										System.out
												.println("Date Of Interview \n"
														+ loanApplicationBean
																.getDateOfInterview());
									}
								} catch (LMSException e) {
									System.out
											.println("Error in fetching data");
								}
								break;
							} else {
								System.out.println("Enter valid Programe Name");
							}
						} while (true);
						//lad 1st functionality ends here
						break;

					//2nd lad functionality start from here 
					case 2:
						boolean checkChangeStatus = false;
						String changeStatus = null;
						long applicationId;
						try {
							System.out
									.println("Welcome to Loan Approval Page\nEnter Application Id to change status");
							applicationId = sc.nextLong();

							System.out.println("Enter status");
							changeStatus = sc.next();

							checkChangeStatus = service.loanApproval(
									applicationId, changeStatus);

							if (checkChangeStatus = true) {
								System.out
										.println("You have sucessfully changed status to "
												+ changeStatus);
							} else
								System.out
										.println("Unable to change Your Status");

						} catch (LMSException e) {
							System.out.println("Error in Approving Loan");
						}

						//2nd lad functionality ends here
					}
					//lad switch ends here		
				}
				//case 2 of main switch ends here
				break;
			case 3:
				do {
					System.out
							.println("Enter Your Application Id to view Your Status");
					long id = sc.nextLong();
					try {
						LoanApplicationBean loan = service
								.viewApplicationStatus(id);

						if (loan.getStatus().equals("Accepted")) {
							System.out
									.println("Your Loan Has been accepted\nYour Scheduled Interview date is:\n"
											+ loan.getDateOfInterview());
							break;
						} else if (loan.getStatus().equals("Approved")) {
							System.out
									.println("Congrats!!! Your Loan Has been Approved\n");
							break;
						} else {
							System.out.println("Your Application Status is: "
									+ loan.getStatus());
							break;
						}

					} catch (LMSException e) {
						System.out
								.println("Invalid Application Id. Re-Enter Your Id");
					}
				} while (true);
				break;
			case 4:
				sc.close();
				System.out.println("Exited From Application");
				System.exit(0);
			}
		}while (true);
	}
}