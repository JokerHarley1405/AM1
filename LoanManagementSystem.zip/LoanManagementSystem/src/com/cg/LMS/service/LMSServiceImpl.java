package com.cg.LMS.service;


import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.LMS.dao.LMSDao;
import com.cg.LMS.dao.LMSDaoImpl;
import com.cg.LMS.dto.*;
import com.cg.LMS.exception.LMSException;

public class LMSServiceImpl implements LMSService{
	
	LMSDao dao=new LMSDaoImpl();
	
	@Override
	public List<LoanProgramBean> viewAllLoans()
			throws LMSException {
		// TODO Auto-generated method stub
		return dao.viewAllLoans();
	}
	
	@Override
	public List<CustomerDetailsBean> getAllDetails(CustomerDetailsBean cus)
			throws LMSException {
		// TODO Auto-generated method stub
		return getAllDetails(cus);
	}
	@Override
	public LoanApplicationBean viewApplicationStatus(long appid)
			throws LMSException {
		// TODO Auto-generated method stub
		return dao.viewApplicationStatus(appid);
	}
	@Override
	public boolean loanApproval(long applicationId, String str)
			throws LMSException {
		// TODO Auto-generated method stub
		return dao.loanApproval(applicationId, str);
	}
	@Override
	public List<LoanApplicationBean> viewApplList(String loanprgm)
			throws LMSException {
		
		return dao.viewApplList(loanprgm);
	}
	
	
	@Override
	public void editLoans() throws LMSException {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public String validateUser(UserBean user) throws LMSException {
		// TODO Auto-generated method stub
		return dao.validateUser(user);
	}

	@Override
	public long applyLoan(CustomerDetailsBean customer,LoanApplicationBean loan) throws LMSException {
		// TODO Auto-generated method stub
		return dao.applyLoan(customer, loan);
	}

	@Override
	public boolean validateCustomer(CustomerDetailsBean cus) throws LMSException {
		
		Pattern pNamePattern =Pattern.compile("^[A-Za-z]{4,20}"); 
		Matcher pNameMatcher =pNamePattern.matcher(cus.getApplicantName());
		 if(!pNameMatcher.find())
			 throw new LMSException("Applicant name should not exceed 20 characters\n");
	
		 Pattern pPhonePattern =Pattern.compile("[0-9]{10}"); 
		 Matcher pPhoneMatcher =pPhonePattern.matcher(String.valueOf(cus.getPhoneNumber()));
		 
		 if(!pPhoneMatcher.find())
			 throw new LMSException("Phone No should be of 10 digits.\n");
		 
		 
		 Pattern mobilePattern =Pattern.compile("[0-9]{10}"); 
		 Matcher mobileMatcher =mobilePattern.matcher(String.valueOf(cus.getMobileNumber()));
		 
		 if(!mobileMatcher.find())
			 throw new LMSException("Mobile No should be of 10 digits.\n");
		 
		 LocalDate today= LocalDate.now();
		 Period p=Period.between(today, cus.getDateOfBirth());
		 int age=p.getYears();
		 if(age<15 && age>85 )
			 throw new LMSException("Please provide a valid Applicant Date Of Birth\n");
		 
		 Pattern emailPattern =Pattern.compile("^[a-zA-Z0-9]+@[a-z]+.[a-z]+$"); 
		Matcher emailMatcher =emailPattern.matcher(cus.getEmail_id());
			 if(!emailMatcher.find())
				 throw new LMSException("Not a valid email");
		 
		return true;
	}

	@Override
	public boolean validateLoanApplication(LoanApplicationBean loan)
			throws LMSException {
		
				return false;
		
	}

	@Override
	public List<LoanApplicationBean> loanProgList(String status, String loanprgm)throws LMSException {
		// TODO Auto-generated method stub
		return dao.loanProgList(status, loanprgm);
	}

	@Override
	public boolean addLoanProg(LoanProgramBean laps) throws LMSException {
		return dao.addLoanProg(laps);
		
	}

	@Override
	public boolean updateLoanProg(int option, String programName, String value)
			throws LMSException {
				return dao.updateLoanProg(option, programName, value);
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean deleteLoanProg(String str) throws LMSException {
		// TODO Auto-generated method stub
		return dao.deleteLoanProg(str);
	}

	@Override
	public boolean validateProgramName(String programName) {
		// TODO Auto-generated method stub
		return dao.validateProgramName(programName);
	}

	

	
}
