package com.cg.LMS.testing;

import java.util.Date;

import junit.framework.Assert;

import org.junit.*;

import com.cg.LMS.dto.CustomerDetailsBean;
import com.cg.LMS.dto.LoanApplicationBean;
import com.cg.LMS.dto.LoanProgramBean;
import com.cg.LMS.exception.LMSException;
import com.cg.LMS.service.LMSService;
import com.cg.LMS.service.LMSServiceImpl;

public class Test_ViewAllLoans {

	
	static LMSService service=new LMSServiceImpl();
	static LoanProgramBean laps = new LoanProgramBean("programName", "description", "type", 5, 10000, 50000, 5, "proofsRequired");
	static LoanApplicationBean lab = new LoanApplicationBean(applicationID, applicationDate, loanProgram, amountOfLoan, addressOfProperty, annualFamilyIncome, documentProofsAvailable, guaranteeCover, marketValueofGuaranteeCover, status, dateOfInterview);
	static CustomerDetailsBean cdb = new CustomerDetailsBean(applicationID, applicantName, dateOfBirth, maritalStatus, phoneNumber, mobileNumber, countOfDependents, email_id);
	
	@Test
	public void testLoanApproval(){
		try {
			Assert.assertEquals(true, service.loanApproval(applicationId, str));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testValidateCustomer(){
		
		Assert.assertEquals(true, service.validateCustomer(cdb));
	}
	
	@Test
	public void testAddLoanProg(){
		
		try {
		Assert.assertEquals(true, service.addLoanProg(laps));
		}
		catch(LMSException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testDeleteLoanProg(){
		String str = "GNS";
		try {
		Assert.assertEquals(true, service.deleteLoanProg(str));
		}
		catch(LMSException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testUpdateLoanProg(){
		int option = 1;
		String programName = "GNS";
		String value = "GND";
		try 
		{
			Assert.assertEquals(true, service.updateLoanProg(option,programName,value));
		}
		catch(LMSException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	@Test
	public void testValidateProgramName(){
		String str = "GNP";
		Assert.assertEquals(true, service.validateProgramName(str));
	}
	
	@Test
	public void testValidateLoanApplication(){
		Date date = new Date();
		LoanApplicationBean loan = new LoanApplicationBean(0,date,"agsa",10000,"asgsag",5000,"PAN","gdsag",10233,"Approved",date);
		try 
		{
			Assert.assertEquals(true, service.validateLoanApplication(loan));
		}
		catch(LMSException e)
		{
			System.out.println(e.getMessage());
		}
	}
}
