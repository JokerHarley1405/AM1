package com.cg.LMS.utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection
{
	static Connection con;
	public static Connection getConnection()
	{
		if(con==null){
			String url;
			String username;
			String password;
			
			try{
				FileInputStream fis=new FileInputStream("./Resources/DBProperty.properties");
				Properties pr=new Properties();
				pr.load(fis);
				url=pr.getProperty("url");
				username=pr.getProperty("username");
				password=pr.getProperty("password");
				
				Class.forName(pr.getProperty("driver"));
				con = DriverManager.getConnection(url,username,password);
				
				//System.out.println("Connected to Database");
				
			}catch(ClassNotFoundException e){
				System.out.println("Class not found");
			}catch(SQLException e){
				System.out.println("not Connected to database");
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				//System.out.println(e.printStackTrace());
				System.out.println("File not found");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println("IO Exception");
			}
		}
		return con;
	}
}
