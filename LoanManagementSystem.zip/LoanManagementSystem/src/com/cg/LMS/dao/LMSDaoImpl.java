package com.cg.LMS.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.LMS.utility.DBConnection;
import com.cg.LMS.dto.*;
import com.cg.LMS.exception.LMSException;

public class LMSDaoImpl implements LMSDao {
	Connection con;

	@Override
	public List<LoanProgramBean> viewAllLoans() throws LMSException {
		List<LoanProgramBean> list = new ArrayList<LoanProgramBean>();
		con = DBConnection.getConnection();

		String query = "select * from LoanProgramsOffered";
		try {
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				LoanProgramBean loan = new LoanProgramBean();
				loan.setProgramName(rs.getString(1));
				loan.setDescription(rs.getString(2));
				loan.setType(rs.getString(3));
				loan.setDurationInYears(rs.getInt(4));
				loan.setMinLoanAmount(rs.getLong(5));
				loan.setMaxLoanAmount(rs.getLong(6));
				loan.setRateOfInterest(rs.getFloat(7));
				loan.setProofsRequired(rs.getString(8));
				list.add(loan);
			}
		} catch (SQLException e) {
			throw new LMSException();
		}

		return list;
	}

	@Override
	public long applyLoan(CustomerDetailsBean cus, LoanApplicationBean laps)
			throws LMSException {
		con = DBConnection.getConnection();
		
		int appId = 0;
		
		String query2 = "INSERT INTO loanapplication VALUES(app_id.nextVal,sysdate,?,?,?,?,?,?,?,?,sysdate+7)";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated

		try {
			PreparedStatement ps = con.prepareStatement(query2);

			ps.setString(1, laps.getLoanProgram());
			ps.setLong(2, laps.getAmountOfLoan());
			ps.setString(3, laps.getAddressOfProperty());
			ps.setLong(4, laps.getAnnualFamilyIncome());
			ps.setString(5, laps.getDocumentProofsAvailable());
			ps.setString(6, laps.getGuaranteeCover());
			ps.setLong(7, laps.getMarketValueofGuaranteeCover());
			ps.setString(8, laps.getStatus());
			// ps.setDate(11, laps.getDateOfInterview());
			
			int r = ps.executeUpdate();

			if (r == 1) {
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery("select app_id.currVal from dual");
				if (rs.next())
					appId = rs.getInt(1);
			}
			
			

			/*
			 * if(r==1){ //Extra Code Statement s= con.createStatement();
			 * ResultSet rs= s.executeQuery("select sysdate+7 from dual");
			 * if(rs.next()) return 0; }
			 */
		} catch (SQLException e) {
			throw new LMSException();
		}
		
		
		
		String query1 = "INSERT INTO customerdetails VALUES(app_id.currVal,?,sysdate,?,?,?,?,?)";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated
		
		try {
			System.out.println("inside try");
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, cus.getApplicantName());

			ps.setString(2, cus.getMaritalStatus());
			ps.setLong(3, cus.getPhoneNumber());
			ps.setLong(4, cus.getMobileNumber());
			ps.setInt(5, cus.getCountOfDependents());
			ps.setString(6, cus.getEmail_id());
			
			ps.executeUpdate();
			
		} catch (SQLException e) {
			throw new LMSException(e.getMessage());
		}

		
		return appId;
	}

	@Override
	public List<CustomerDetailsBean> getAllDetails(CustomerDetailsBean cus)
			throws LMSException {
		con = DBConnection.getConnection();
		List<CustomerDetailsBean> list = new ArrayList<CustomerDetailsBean>();
		String query1 = "select * from customerdetails where application_id=?";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated

		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setLong(1, cus.getApplicationID());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				CustomerDetailsBean cus1 = new CustomerDetailsBean();
				cus1.setApplicantName(rs.getString(2));
				// cus1.setDateOfBirth(rs.getDate(3));
				cus1.setMaritalStatus(rs.getString(4));
				cus1.setPhoneNumber(rs.getInt(5));
				cus1.setMobileNumber(rs.getInt(6));
				cus1.setCountOfDependents(rs.getInt(7));
				cus1.setEmail_id(rs.getString(8));
				list.add(cus1);
			}
		} catch (SQLException e) {
			throw new LMSException();
		}
		return list;
	}

	@Override
	public LoanApplicationBean viewApplicationStatus(long appId)
			throws LMSException {
		con = DBConnection.getConnection();
		String query1 = "select * from loanapplication where application_Id =?";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated
		LoanApplicationBean laps = new LoanApplicationBean();
		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setLong(1, appId);
			ResultSet rs = ps.executeQuery();
			// System.out.println(rs.next());
			while (rs.next()) {
				
				laps.setApplicationID(rs.getLong(1));
				laps.setApplicationDate(rs.getDate(2));
				laps.setLoanProgram(rs.getString(3));
				laps.setAmountOfLoan(rs.getLong(4));
				laps.setAddressOfProperty(rs.getString(5));
				laps.setAnnualFamilyIncome(rs.getLong(6));
				laps.setDocumentProofsAvailable(rs.getString(7));
				laps.setGuaranteeCover(rs.getString(8));
				laps.setMarketValueofGuaranteeCover(rs.getLong(9));
				laps.setStatus(rs.getString(10));
				laps.setDateOfInterview(rs.getDate(11));
				return laps;
			}
		} catch (SQLException e) {
			throw new LMSException();
		}
		return null;
	}

	@Override
	public boolean loanApproval(long applicationId, String str)
			throws LMSException {
		con = DBConnection.getConnection();

		String query1 = "update loanapplication set status=? where application_id=?";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated
		LoanApplicationBean laps = new LoanApplicationBean();


		switch (str) {
		case "Accepted":// for accepting loan application
			try {
				PreparedStatement ps = con.prepareStatement(query1);
				ps.setString(1, "Accepted");
				ps.setLong(2, laps.getApplicationID());
				int rs = ps.executeUpdate();
				if (rs>0) {
					return true;
				} else {
					return false;
				}
			}catch (SQLException e) {
				throw new LMSException();
			}
			
		case "Approved":// for approving loan
			try {
				PreparedStatement ps = con.prepareStatement(query1);
				ps.setString(1, "Approved");
				ps.setLong(2, laps.getApplicationID());
				int rs = ps.executeUpdate();
				if (rs>0) {
					return true;
				} else {
					return false;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
			

		case "Rejected":// for rejecting loan
			try {
				PreparedStatement ps = con.prepareStatement(query1);
				ps.setString(1, "Rejected");
				ps.setLong(2, laps.getApplicationID());
				int rs = ps.executeUpdate();
				if (rs>0) {
					return true;
				} else {
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}

		default:
			break;
		}
		return true;
	}

	@Override
	public List<LoanApplicationBean> viewApplList(String loanprgm)
			throws LMSException {
		con = DBConnection.getConnection();
		List<LoanApplicationBean> list = new ArrayList<LoanApplicationBean>();
		String query1 = "select * from loanapplication where loan_program=?";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated
		LoanApplicationBean laps = new LoanApplicationBean();
		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, loanprgm);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				laps.setApplicationID(rs.getLong(1));
				laps.setApplicationDate(rs.getDate(2));
				laps.setLoanProgram(rs.getString(3));
				laps.setAmountOfLoan(rs.getLong(4));
				laps.setAddressOfProperty(rs.getString(5));
				laps.setAnnualFamilyIncome(rs.getLong(6));
				laps.setDocumentProofsAvailable(rs.getString(7));
				laps.setGuaranteeCover(rs.getString(8));
				laps.setMarketValueofGuaranteeCover(rs.getLong(9));
				laps.setStatus(rs.getString(10));
				laps.setDateOfInterview(rs.getDate(11));
				list.add(laps);
			}
		} catch (SQLException e) {
			throw new LMSException();
		}
		return list;

	}

	/*
	 * @Override public List<LoanProgramBean> loanProgList() throws LMSException
	 * { con= DBConnection.getConnection(); List<LoanProgramBean> list=new
	 * ArrayList<LoanProgramBean>(); String
	 * query1="select * from loanprogramsoffered"; // Gauhar's SQL login: trg9
	 * is used. Sequence app_id is generated CustomerDetailsBean cus1= new
	 * CustomerDetailsBean(); try { PreparedStatement ps=
	 * con.prepareStatement(query1); ps.setLong(1, cus.getApplicationID());
	 * ResultSet rs= ps.executeQuery(); while(rs.next()){
	 * 
	 * 
	 * cus1.setApplicantName(rs.getString(2));
	 * cus1.setDateOfBirth(rs.getDate(3));
	 * cus1.setMaritalStatus(rs.getString(4));
	 * cus1.setPhoneNumber(rs.getInt(5)); cus1.setMobileNumber(rs.getInt(6));
	 * cus1.setCountOfDependents(rs.getInt(7));
	 * cus1.setEmail_id(rs.getString(8)); list.add(cus1); } }catch(SQLException
	 * e){ throw new LMSException(
	 * "Problem in inserting loan details in customerdetails table. Error: "
	 * +e.getMessage()); } return list; } return null; }
	 */

	/*
	 * @Override public void editLoans(int option) throws LMSException {
	 * 
	 * Scanner sc = new Scanner(System.in); System.out.println("Edit Loan ");
	 * System.out.println("1. Add a new loan program");
	 * System.out.println("2. Update existing loan program");
	 * System.out.println("3. Remove an existing loan program"); // This should
	 * // be in UI option = sc.nextInt(); switch (option) { case 1: // 1. Add a
	 * new loan program System.out.println("You have chosen to add new loan.");
	 * addLoanProg(LoanProgramBean); break; case 2: // 2. Update existing loan
	 * program System.out.println("Enter the loan programme to be update: "); //
	 * updateLoanProg(); break; case 3: // 3. Remove an existing loan program
	 * System.out.println("Enter the loan programme to be removed: "); String
	 * loanToBeRemoved = sc.next(); deleteLoanProg(loanToBeRemoved); break;
	 * default: break; }
	 * 
	 * }
	 */

	public boolean deleteLoanProg(String str) throws LMSException {
		con = DBConnection.getConnection();
		LoanProgramBean laps = new LoanProgramBean();
		String query1 = "delete from loanprogramsoffered where programname=?";
		// Update program type
		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, str);
			int rs = ps.executeUpdate();
			if (rs != 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			throw new LMSException(e.getMessage());
		}
	}

	public boolean addLoanProg(LoanProgramBean laps) throws LMSException {
		con = DBConnection.getConnection();
		// LoanProgramBean laps= new LoanProgramBean();
		String query1 = "insert into loanprogramsoffered values(?,?,?,?,?,?,?,?)";
		// Update program type
		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, laps.getProgramName());
			ps.setString(2, laps.getDescription());
			ps.setString(3, laps.getType());
			ps.setInt(4, laps.getDurationInYears());
			ps.setLong(5, laps.getMinLoanAmount());
			ps.setLong(6, laps.getMaxLoanAmount());
			ps.setFloat(7, laps.getRateOfInterest());
			ps.setString(8, laps.getProofsRequired());
			int rs = ps.executeUpdate();
			if (rs != 0) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			throw new LMSException(e.getMessage());
		}

	}

	public boolean updateLoanProg(int option, String programName, String value)
			throws LMSException {
		con = DBConnection.getConnection();
		
		switch (option) {
		case 1:
			// Update program type
			String query1 = "update loanprogramsoffered set type=? where programname=?";
		
			try {
				PreparedStatement ps = con.prepareStatement(query1);
		
				ps.setString(1, value);
				ps.setString(2, programName);
				
				int rs=ps.executeUpdate();
				System.out.println("Rs= "+rs);
				while (rs>0) {
					System.out.println("inside while loop in case 1");
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
		case 2:
			// update program duration in years
			String query2 = "update loanprogramsoffered set durationinyears=? where programname=?";
			
			try {
				int duration = Integer.parseInt(value);
				PreparedStatement ps = con.prepareStatement(query2);
			
				ps.setInt(1, duration);
				ps.setString(2, programName);
				int rs=ps.executeUpdate();
				
				System.out.println("Rs= "+rs);
				while (rs>0) {
					System.out.println("inside while loop in case 2");
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
		case 3:
			// update minimum loan amount
			String query3 = "update loanprogramsoffered set minloanamount=? where programname=?";
			
			try {
				PreparedStatement ps = con.prepareStatement(query3);
				long min = Long.parseLong(value);
				
				ps.setLong(1, min);
				ps.setString(2, programName);
				int rs=ps.executeUpdate();
				System.out.println("Rs= "+rs);
				while (rs>0) {
					System.out.println("inside while loop in case 3");
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
		case 4:
			// update maximum loan amount
			String query4 = "update loanprogramsoffered set maxloanamount=? where programname=?";
			
			try {
				PreparedStatement ps = con.prepareStatement(query4);
				long max = Long.parseLong(value);
			
				ps.setLong(1, max);
				ps.setString(2, programName);
				int rs=ps.executeUpdate();
				System.out.println("Rs= "+rs);
				while (rs>0) {
					System.out.println("inside while loop in case 4");
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
		case 5:
			// update rate of interest
			String query5 = "update loanprogramsoffered set rateofinterest=? where programname=?";
			
			try {
				PreparedStatement ps = con.prepareStatement(query5);
				System.out.println("inside case5");
				float interest = Float.parseFloat(value);
				//ps.setString(1, str);
				ps.setFloat(1, interest);
				ps.setString(2, programName);
				int rs=ps.executeUpdate();
				System.out.println("Rs= "+rs);
				while (rs>0) {
					System.out.println("inside while loop in case 5");
					return true;
				}
			} catch (SQLException e) {
				throw new LMSException();
			}
		}
		return false;
	}

	@Override
	public String validateUser(UserBean user) throws LMSException {
		con = DBConnection.getConnection();
		String role = null;
		String query1 = "select password, role from users where login_id=?";
		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, user.getLoginID());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString(1).equals(user.getPassword())) {
					role = rs.getString(2);
				} else {
					role="";
				}

			}
		} catch (SQLException e) {
			throw new LMSException();
		}

		return role;
	}

	@Override
	public List<LoanApplicationBean> loanProgList(String status, String loanprgm)
			throws LMSException {
		con = DBConnection.getConnection();
		List<LoanApplicationBean> list = new ArrayList<LoanApplicationBean>();
		String query1 = "select * from loanapplication where loan_program=? and status=?";
		// Gauhar's SQL login: trg9 is used. Sequence app_id is generated

		try {
			PreparedStatement ps = con.prepareStatement(query1);
			ps.setString(1, loanprgm);
			ps.setString(2, status);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				do {
					LoanApplicationBean laps = new LoanApplicationBean();
					laps.setApplicationID(rs.getLong(1));
					laps.setApplicationDate(rs.getDate(2));
					laps.setLoanProgram(rs.getString(3));
					laps.setAmountOfLoan(rs.getLong(4));
					laps.setAddressOfProperty(rs.getString(5));
					laps.setAnnualFamilyIncome(rs.getLong(6));
					laps.setDocumentProofsAvailable(rs.getString(7));
					laps.setGuaranteeCover(rs.getString(8));
					laps.setMarketValueofGuaranteeCover(rs.getLong(9));
					laps.setStatus(rs.getString(10));
					laps.setDateOfInterview(rs.getDate(11));
					list.add(laps);
				} while (rs.next());
			} else {
				throw new LMSException("Nothing found");
			}
		} catch (SQLException e) {
			throw new LMSException("Problem in viewing all programs"
					+ e.getMessage());
		}
		return list;
	}

	@Override
	public boolean validateProgramName(String programName) {
		con = DBConnection.getConnection();
		String query1 = "select programname from loanprogramsoffered";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(query1);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString("programname").equals(programName)) {
					return true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				return false;
	}

}
