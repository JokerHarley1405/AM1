package com.cg.LMS.dao;

import java.util.List;

import com.cg.LMS.dto.*;
import com.cg.LMS.exception.LMSException;

public interface LMSDao {
	public List<LoanProgramBean> viewAllLoans() throws LMSException;
	
	public long applyLoan(CustomerDetailsBean cus, LoanApplicationBean laps) throws LMSException;
	
	public List<CustomerDetailsBean> getAllDetails(CustomerDetailsBean cus) throws LMSException;
	
	public LoanApplicationBean viewApplicationStatus(long appId) throws LMSException;
	
	public boolean loanApproval(long applicationId, String str) throws LMSException;
	
	public List<LoanApplicationBean> viewApplList(String loanprgm) throws LMSException;
	
	public List<LoanApplicationBean> loanProgList(String status, String loanprgm) throws LMSException;
	
	
	
	//public boolean validateCustomer(CustomerDetailsBean cus, LoanApplicationBean laps) throws LMSException;
	
	public boolean updateLoanProg(int option, String programName, String value) throws LMSException;
	
	public String validateUser(UserBean user) throws LMSException;
	
	public boolean deleteLoanProg(String str) throws LMSException;
	
	public boolean addLoanProg(LoanProgramBean laps) throws LMSException;
	
	public boolean validateProgramName(String programName);
	
	
}
