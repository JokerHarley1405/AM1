package com.cg.LMS.dto;

import java.util.Date;

public class LoanApplicationBean {

	@Override
	public String toString() {
		return "LoanApplicationBean [applicationID=" + applicationID
				+ ", applicationDate=" + applicationDate + ", loanProgram="
				+ loanProgram + ", amountOfLoan=" + amountOfLoan
				+ ", addressOfProperty=" + addressOfProperty
				+ ", annualFamilyIncome=" + annualFamilyIncome
				+ ", documentProofsAvailable=" + documentProofsAvailable
				+ ", guaranteeCover=" + guaranteeCover
				+ ", marketValueofGuaranteeCover="
				+ marketValueofGuaranteeCover + ", status=" + status
				+ ", dateOfInterview=" + dateOfInterview + "]";
	}
	private long applicationID ;
	private Date applicationDate;
	private String loanProgram;
	private long amountOfLoan ;
	private String addressOfProperty ;
	private long annualFamilyIncome ;
	private String documentProofsAvailable;
	private String guaranteeCover; 
	public LoanApplicationBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoanApplicationBean(long applicationID, Date applicationDate,
			String loanProgram, long amountOfLoan, String addressOfProperty,
			long annualFamilyIncome, String documentProofsAvailable,
			String guaranteeCover, long marketValueofGuaranteeCover,
			String status, Date dateOfInterview) {
		super();
		this.applicationID = applicationID;
		this.applicationDate = applicationDate;
		this.loanProgram = loanProgram;
		this.amountOfLoan = amountOfLoan;
		this.addressOfProperty = addressOfProperty;
		this.annualFamilyIncome = annualFamilyIncome;
		this.documentProofsAvailable = documentProofsAvailable;
		this.guaranteeCover = guaranteeCover;
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}
	private long marketValueofGuaranteeCover;
	private String status; 
	private Date dateOfInterview;
	
	
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}
	public Date getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getLoanProgram() {
		return loanProgram;
	}
	public void setLoanProgram(String loanProgram) {
		this.loanProgram = loanProgram;
	}
	public long getAmountOfLoan() {
		return amountOfLoan;
	}
	public void setAmountOfLoan(long amountOfLoan) {
		this.amountOfLoan = amountOfLoan;
	}
	public String getAddressOfProperty() {
		return addressOfProperty;
	}
	public void setAddressOfProperty(String addressOfProperty) {
		this.addressOfProperty = addressOfProperty;
	}
	public long getAnnualFamilyIncome() {
		return annualFamilyIncome;
	}
	public void setAnnualFamilyIncome(long annualFamilyIncome) {
		this.annualFamilyIncome = annualFamilyIncome;
	}
	public String getDocumentProofsAvailable() {
		return documentProofsAvailable;
	}
	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		this.documentProofsAvailable = documentProofsAvailable;
	}
	public String getGuaranteeCover() {
		return guaranteeCover;
	}
	public void setGuaranteeCover(String guaranteeCover) {
		this.guaranteeCover = guaranteeCover;
	}
	public long getMarketValueofGuaranteeCover() {
		return marketValueofGuaranteeCover;
	}
	public void setMarketValueofGuaranteeCover(long marketValueofGuaranteeCover) {
		this.marketValueofGuaranteeCover = marketValueofGuaranteeCover;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDateOfInterview() {
		return dateOfInterview;
	}
	public void setDateOfInterview(Date dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}
}
