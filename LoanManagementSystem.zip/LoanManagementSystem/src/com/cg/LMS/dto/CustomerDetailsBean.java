package com.cg.LMS.dto;

import java.time.LocalDate;



public class CustomerDetailsBean {

	private long applicationID ;
	private String applicantName ;
	private LocalDate dateOfBirth;
	private String maritalStatus;
	private long phoneNumber ;
	private long mobileNumber ;
	private int countOfDependents ;
	private String email_id ; //changed to emailId
	
	public CustomerDetailsBean() {
		// TODO Auto-generated constructor stub
	}
	
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public int getCountOfDependents() {
		return countOfDependents;
	}
	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public CustomerDetailsBean(long applicationID, String applicantName,
			LocalDate dateOfBirth, String maritalStatus, long phoneNumber,
			long mobileNumber, int countOfDependents, String email_id) {
		super();
		this.applicationID = applicationID;
		this.applicantName = applicantName;
		this.dateOfBirth = dateOfBirth;
		this.maritalStatus = maritalStatus;
		this.phoneNumber = phoneNumber;
		this.mobileNumber = mobileNumber;
		this.countOfDependents = countOfDependents;
		this.email_id = email_id;
	}
	
}
