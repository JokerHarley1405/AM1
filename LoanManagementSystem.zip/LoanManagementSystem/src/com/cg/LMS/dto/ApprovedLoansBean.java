package com.cg.LMS.dto;

public class ApprovedLoansBean {

	private long applicationID;
	private String customerName ;
	private long amountOfLoanGranted;
	private long monthlyInstallment;
	private long yearsTimePeriod;
	private long downPayment;
	private float rateOfInterest ;
	private long totalAmountPayable ;
	
	public long getApplicationID() {
		return applicationID;
	}
	public void setApplicationID(long applicationID) {
		this.applicationID = applicationID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getAmountOfLoanGranted() {
		return amountOfLoanGranted;
	}
	public void setAmountOfLoanGranted(long amountOfLoanGranted) {
		this.amountOfLoanGranted = amountOfLoanGranted;
	}
	public long getMonthlyInstallment() {
		return monthlyInstallment;
	}
	public void setMonthlyInstallment(long monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}
	public long getYearsTimePeriod() {
		return yearsTimePeriod;
	}
	public void setYearsTimePeriod(long yearsTimePeriod) {
		this.yearsTimePeriod = yearsTimePeriod;
	}
	public long getDownPayment() {
		return downPayment;
	}
	public void setDownPayment(long downPayment) {
		this.downPayment = downPayment;
	}
	public float getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(float rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public long getTotalAmountPayable() {
		return totalAmountPayable;
	}
	public void setTotalAmountPayable(long totalAmountPayable) {
		this.totalAmountPayable = totalAmountPayable;
	}
}
