package com.cg.loan.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;













import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanApplication;
import com.cg.loan.bean.LoanProgram;
import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;
import com.cg.loan.service.IService;
import com.cg.loan.service.IUserService;
import com.cg.loan.service.Serviceimp;
import com.cg.loan.service.UserServiceImpl;

public class Client {
	static Scanner sc = new Scanner(System.in);
	static IService Service = null;
	static Serviceimp Serviceimpl = null;
	static Logger logger = Logger.getRootLogger();
	
	static IUserService iUserService;
	static Users users = null;
	static ApprovedLoans approvedloans = null;
	static Customer cust=null; 
	static LoanApplication loanApp=null;
	static  LoanProgram loanprogram=null;
	static String loanId = null;
	
	public static void main(String[] args) throws LoanException {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("resources//log4j.properties");
		
		
		
		int option = 0;
		while (true) {

			// show menu
			
			System.out.println(".....................  LOAN MANAGEMENT PROCESSING SYSTEM.......... ");
			System.out.println("-----------------------------------------------------------------------\n");

			System.out.println("1.CUSTOMER ");
			System.out.println("2.LOGIN FOR ADMIN AND LAD");
			System.out.println("3.LAD");
			System.out.println("4.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:
					viewCustomer();
					break;
				case 2: 
					ValidFunc();
					break;
				case 3:
					ValidFunc();
					
					break;
				case 4:
					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				// end of switch
			
				}
				
		}
			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			
		}
				
		
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
//Customer
	private static void viewCustomer() {
		String appId = null;
		int option = 0;
		while (true) {
			System.out.println("--------------------------------CUSTOMER---------------------------------");
			System.out.println("-----------------------------------------------------------------------\n");
			System.out.println("1. View Loan Programs");
			System.out.println("2. ApplyLoan");
			System.out.println("3. View Status");
			System.out.println("4. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:
					Service = new Serviceimp();
					try {
						List<LoanProgram> laList = new ArrayList<LoanProgram>();
						laList = Service.viewAllLoan();

						for(LoanProgram i:laList)
						{
							System.out.println(i.getLoanId()+"\t"
												+i.getProgramName()+"\t"
												+i.getDescription()+"\t"
												+i.getType()+"\t"
												+i.getDurationInYears()+"\t"
												+i.getMinLoanAmount()+"\t"
												+i.getMaxLoanAmount()+"\t"
												+i.getRateOfInterest()+"\t"
												+i.getProofsRequired());
						}
						
			}

					catch (LoanException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
				case 2:
					while (loanApp == null && cust == null ) {
						
						loanApp =  populateDonorBean1();
						cust = populateDonorBean();
						// System.out.println(donorBean);
					}

					try {
						Service = new Serviceimp();
						appId = Service.applyForLoan(loanApp, cust);

						System.out.println("Application details  has been successfully registered ");
						System.out.println("Application ID Is: " + appId);
						System.out.println("\n\n**Thank you for appling for loan, you will be intimated later regarding interview date and time.");

					} catch (LoanException loanException) {
						logger.error("exception occured", loanException);
						System.out.println("ERROR : "
								+ loanException.getMessage());
					} /*finally {
						appId = null;
						Service = null;
						cust = null;
						loanApp=null;
					}*/

					break;
				case 3:
					Service = new Serviceimp();
					System.out.println("Enter numeric Application id:");
					appId = sc.next();

					loanApp = getDonorDetails(appId);
					//System.out.println(appId);
					if (loanApp != null) {
						
						System.out.println("Applicant Status is  :"
								+ loanApp.getStatus());
						System.out.println("Your interview scheduled date will be Reported soon");
					} else {
						System.err
						.println("There are no Application details associated with Application id "
										+appId );
					}

					break;	
				case 4:
					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
				
			}catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}
			
		}		
}
	private static Customer populateDonorBean() {
		// TODO Auto-generated method stub
		Customer cust= new Customer();
		
		System.out.println("Enter Applicant name: ");
		cust.setApplicantName(sc.next());
		
		System.out.println("Enter Dob : ");
		cust.setDob(sc.next());
		
		System.out.println("Enter Marital status : ");
		cust.setMarital_status(sc.next());
		
		System.out.println("Enter Mobile number : ");
		cust.setMobile_number(sc.next());
		
		System.out.println("Enter Count of Dependents : ");
		cust.setCountofDependents(sc.nextInt());
	
		System.out.println("Enter Email ID Dependents : ");
		cust.setEmailId(sc.next());
		Serviceimpl = new Serviceimp();

		
		try {
			Serviceimpl.validateCustomer(cust);
			return cust;
		} catch (LoanException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);
		}
		return null;
	}
	private static LoanApplication populateDonorBean1() {
		// TODO Auto-generated method stub
		LoanApplication loanApp = new LoanApplication();
		
		System.out.println("\n Enter Details");
		
		System.out.println("Enter Loan Program: ");
		loanApp.setLoan_program(sc.next());
		
		System.out.println("Enter Amount of Loan: ");
		loanApp.setAmountofLoan(sc.nextDouble());
		
		System.out.println("Enter Address of Property: ");
		loanApp.setAddressofProperty(sc.next());
		
		System.out.println("Enter Annual Family Income: ");
		loanApp.setAnnualFamilyIncome(sc.nextDouble());
		
		System.out.println("Enter Document Proofs Available: ");
		loanApp.setDocumentProofsAvailable(sc.next());
		
		System.out.println("Enter Guarantee Cover: ");
		loanApp.setGuaranteeCover(sc.next());
		
		System.out.println("Enter Market Value of Guarantee Cover: ");
		loanApp.setMarketValueofGuaranteeCover(sc.nextDouble());
		
		System.out.println("Enter Loan_id: ");
		loanApp.setLoan_id(sc.nextInt());
		
		Serviceimpl = new Serviceimp();

		try {
			Serviceimpl.validateloanapp(loanApp);
			return loanApp;
		} catch (LoanException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;
	}
	
	private static LoanApplication getDonorDetails(String applicationId) {
		LoanApplication donorBean = null;
		Service = new Serviceimp();
		

		try {
			try {
				donorBean = Service.viewLoanStatus(applicationId);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (LoanException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		Service = null;
		return donorBean;
	}


		
		
		
	
//LAD
	private static void LadFunc() throws LoanException{
		
		String loanID = null;
		String appId = null;
		int option = 0;
		while (true) {
			System.out.println("--------------------------------LAD---------------------------------");
			System.out.println("-----------------------------------------------------------------------\n");
			System.out.println("1. View Loan Programs");
			System.out.println("2. View Application Details");
			System.out.println("3. View Customer Details");
			System.out.println("4. Update Application Status");
			System.out.println("5. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option
 
			try {
				option = sc.nextInt();
 
				switch (option) {
 
				case 1:
					Service = new Serviceimp();
					try {
						List<LoanProgram> laList = new ArrayList<LoanProgram>();
						laList = Service.viewAllLoan();
 
						for(LoanProgram i:laList)
						{
							System.out.println(i.getLoanId()+"\t"
												+i.getProgramName()+"\t"
												+i.getDescription()+"\t"
												+i.getType()+"\t"
												+i.getDurationInYears()+"\t"
												+i.getMinLoanAmount()+"\t"
												+i.getMaxLoanAmount()+"\t"
												+i.getRateOfInterest()+"\t"
												+i.getProofsRequired());
						}
 
			}
					catch (LoanException e) {
 
						System.out.println("Error  :" + e.getMessage());
					}
					LadFunc();
					break;
 
				case 2:
					
					Service = new Serviceimp();
					System.out.println("Enter numeric loan id:");
					loanID = sc.next();
					List<LoanApplication> list =new ArrayList<LoanApplication>();
					list = getappbyId(loanID);
					//System.out.println(appId);
					if (list != null) {
						for (LoanApplication loanApplication : list) {
							System.out.println("Applicant Id is  :"+"\t"
									+ loanApplication.getApplication_id()
									+"\n Application Date is  :" + "\t"
									+loanApplication.getApplication_date()
									+"\n Loan_program is :"+"\t"
									+loanApplication.getLoan_program()
									+"\n AmountofLoan is :"+"\t"
									+loanApplication.getAmountofLoan()
									+"\n AddressofProperty is :"+"\t"
									+loanApplication.getAddressofProperty()
									+"\n AnnualFamilyIncome is :"+"\t"
									+loanApplication.getAnnualFamilyIncome()
									+"\n DocumentProofsAvailable is :"+"\t"
									+loanApplication.getDocumentProofsAvailable()
									+"\n GuaranteeCover is :"+"\t"
									+loanApplication.getGuaranteeCover()
									+"\n Market Value of GuaranteeCover is :" +"\t"
									+loanApplication.getMarketValueofGuaranteeCover()
									+"\n Status is :"+"\t"
									+loanApplication.getStatus()+
									"\n**********************************************************"
									);
							
						}
						
					} else {
						System.err
						.println("There are no Application details associated with loan id "
										+loanID );
					}
					LadFunc();
					break;
					
				case 3:
					Service = new Serviceimp();
					System.out.println("Enter numeric Application id:");
					appId = sc.next();
					cust = getCustomerDetailsByID(appId);
					if (cust != null) {
 
						System.out.println("Customer Name is  :" +"\t"
								+ cust.getApplicantName()
								+"\n Customer Dob is  :" +"\t"
								+ cust.getDob()
								+"\n Customer Marital_status is  :" +"\t"
								+ cust.getMarital_status()
								+"\n Customer Mobile no. is  :" +"\t"
								+ cust.getMobile_number()
								+"\n Customer Count of Dependents is  :" +"\t"
								+ cust.getCountofDependents()
								+"\n Customer Email Id is  :" +"\t"
								+ cust.getEmailId()
								);
					} else {
						System.err
						.println("There are no Application details associated with Application id "
										+appId );
					}
					LadFunc();
					break;
				case 4:
					LoanApplication lbean=new LoanApplication();
					System.out.println("Enter Application Id whose details need to be updated");
						String Id=sc.next();
						Service = new Serviceimp();
						String mod="";
							 System.out.println("Enter Status");
								mod=mod.concat(" Status='"+sc.next()+"'");
								
								Service.updateLoanAppln(mod, Id);
								LadFunc();
								break;
					case 5:
 
					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-5]");
					LadFunc();
				// end of switch
				}
 
			}catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			} catch (LoanException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
 
}		
			
	/*private static LoanApplication getAppDetailsByID(String loanID) {
		LoanApplication donorBean = null;
		Service = new Serviceimp();
 
		try {
			donorBean = Service.ViewForLoanAppID(loanID);
		} catch (LoanException loanException) {
			logger.error("exception occured ", loanException);
			System.out.println("ERROR : " + loanException.getMessage());
		}
		Service = null;
		return donorBean;
	}*/
	private static  List<LoanApplication> getappbyId(String loanID) {
		// TODO Auto-generated method stub
	Service = new Serviceimp();
	List<LoanApplication> list =new ArrayList<LoanApplication>();

	try {
		try {
			list = Service.viewLoanbyID(loanID);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (LoanException donarException) {
		logger.error("exception occured ", donarException);
		System.out.println("ERROR : " + donarException.getMessage());
	}

	Service = null;
	return list;
}
	
private static Customer getCustomerDetailsByID(String appId) {
	Customer donorBean = null;
	Service = new Serviceimp();
 
	try {
		donorBean = Service.viewCustomerDetails(appId);
	} catch (LoanException loanException) {
		logger.error("exception occured ", loanException);
		System.out.println("ERROR : " + loanException.getMessage());
	}
	Service = null;
	return donorBean;
}
		
		































//Admin
	private static void ValidFunc() throws LoanException {
		
		System.out.println("Enter username");
		String login_id = new Scanner(System.in).nextLine();
		System.out.println("Enter password");

		String passWord = new Scanner(System.in).nextLine();
		System.out.println("Enter role");

		String role = new Scanner(System.in).nextLine();
		users = new Users();
		users.setLogin_id(login_id);
		users.setPassword(passWord);
		users.setRole(role);
		iUserService = new UserServiceImpl();
		users = iUserService.getAuthentication(users);
		if((login_id.equals("admin") && passWord.equals("capg123") && role.equals("admin")))
		{
			AdminFunc();	
		}
		else if((login_id.equals("lad") && passWord.equals("capg123") && role.equals("lad"))){
			
			LadFunc();
		}else
		{
			System.out.println("*******************************please enter valid Login details******************************************");
		}
		
	}
	
	

private static void AdminFunc() throws LoanException {
	// TODO Auto-generated method stub
	System.out.println("--------------------------------Admin---------------------------------");
	System.out.println("-----------------------------------------------------------------------\n");

			int option=0;
			System.out.println("1. Update/Manage Loan Programs");
			System.out.println("2. View Application Details");
			System.out.println("3. View Customer Details");
			System.out.println("4. Insert details");
			System.out.println("5. Delete");
			System.out.println("6. Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			while(true){
			
				option = sc.nextInt();

				switch (option) {

				case 1:
					update();
					AdminFunc();
					break;
				case 2:
					String loanID=null;
					Service = new Serviceimp();
					System.out.println("Enter numeric Loan id:");
					loanID = sc.next();
					List<LoanApplication> list =new ArrayList<LoanApplication>();
					list = getappbyId(loanID);
					//System.out.println(appId);
					if (list != null) {
						for (LoanApplication loanApplication : list) {
							System.out.println("Applicant Id is  :"+"\t"
									+ loanApplication.getApplication_id()
									+"\n Application Date is  :" + "\t"
									+loanApplication.getApplication_date()
									+"\n Loan_program is :"+"\t"
									+loanApplication.getLoan_program()
									+"\n AmountofLoan is :"+"\t"
									+loanApplication.getAmountofLoan()
									+"\n AddressofProperty is :"+"\t"
									+loanApplication.getAddressofProperty()
									+"\n AnnualFamilyIncome is :"+"\t"
									+loanApplication.getAnnualFamilyIncome()
									+"\n DocumentProofsAvailable is :"+"\t"
									+loanApplication.getDocumentProofsAvailable()
									+"\n GuaranteeCover is :"+"\t"
									+loanApplication.getGuaranteeCover()
									+"\n Market Value of GuaranteeCover is :" +"\t"
									+loanApplication.getMarketValueofGuaranteeCover()
									+"\n Status is :"+"\t"
									+loanApplication.getStatus()+
									"\n**********************************************************"
									);
							
						}
						
					} else {
						System.err
						.println("There are no Application details associated with Loan id "
										+loanID );
					}
					AdminFunc();
					break;
					
				case 3:
					Service = new Serviceimp();
					String appId= null;
					System.out.println("Enter numeric Application id:");
					appId = sc.next();
					cust = getCustomerDetailsByID(appId);
					if (cust != null) {
 
						System.out.println("Customer Name is  :" +"\t"
								+ cust.getApplicantName()
								+"\n Customer Dob is  :" +"\t"
								+ cust.getDob()
								+"\n Customer Marital_status is  :" +"\t"
								+ cust.getMarital_status()
								+"\n Customer Mobile no. is  :" +"\t"
								+ cust.getMobile_number()
								+"\n Customer Count of Dependents is  :" +"\t"
								+ cust.getCountofDependents()
								+"\n Customer Email Id is  :" +"\t"
								+ cust.getEmailId()
								);
					} else {
						System.err
						.println("There are no Application details associated with Application id "
										+appId );
					}
					AdminFunc();
					break;
					
				case 4: 
					insertdetails();
					AdminFunc();
					break;
				case 5: 
					Delete();
					AdminFunc();
					break;
				
				case 6:
                    System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-6]");
					AdminFunc();
				}
			}
	}


private static  void Delete() {
	// TODO Auto-generated method stub
	Service = new Serviceimp();
	System.out.println("Enter LoanId\n");
	@SuppressWarnings("resource")
	String loanId = new Scanner(System.in).nextLine();
	try {

		Service.deleteLoanProgram(loanId);	
	} catch (LoanException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}




private static void update() throws LoanException {
	// TODO Auto-generated method stub
	Service = new Serviceimp();
	System.out.println("Enter loan Id to Modify");
	int id1=sc.nextInt();
	int opt=0;
	String mod="";

	while(true)
	{
	System.out.println("To Modify\n1:program name\n2:description\n3:type\n4:durationinyears\n5:min_loan_amount\n6:max_loan_amount\n7:rate_of_interest\n8:proofs_required");
	opt=sc.nextInt();	
	if(opt!=9 && !mod.equals(""))
		mod=mod.concat(",");
	switch(opt)
	{
	case 1: System.out.println("Enter Program");
			mod=mod.concat(" Program_Name='"+sc.next()+"'");
			
			break;
	case 2: System.out.println("Enter description");
			mod=mod.concat(" description='"+sc.next()+"'");
			break;
	case 3: System.out.println("Enter type");
			mod=mod.concat(" type='"+sc.next()+"'");
			break;
	case 4: System.out.println("Enter durationinyears ");
			mod=mod.concat(" durationinyears="+sc.nextInt());
			break;
	
	case 5: System.out.println("Enter min_loan_amount");
			mod=mod.concat(" min_loan_amount='"+sc.nextDouble()+"'");
			break;
	case 6: System.out.println("Enter max_loan_amount");
			mod=mod.concat(" max_loan_amount="+sc.nextDouble());
			break;
	case 7: System.out.println("Enter rate_of_interest");
			mod=mod.concat(" rate_of_interest='"+sc.nextDouble()+"'");
			break;
	case 8: System.out.println("Enter proofs_required ");
			mod=mod.concat(" proofs_required ='"+sc.next()+"'");
			break;
    case 9:System.exit(1);
			break;
	}
	Service.update(mod,id1);
	break;
	}	
	

}
private static void insertdetails() throws LoanException

{
	approvedloans =  populateadminBean();
	
	try {
		Service = new Serviceimp();
		 Service.insertApproved(approvedloans);

		System.out.println("Application details  has been successfully registered ");
		
		System.out.println("\n\n**Thank you for appling for loan, you will be intimated later regarding interview date and time.");

	} catch (LoanException loanException) {
		logger.error("exception occured", loanException);
		System.out.println("ERROR : "
				+ loanException.getMessage());
	} 
}


private static ApprovedLoans populateadminBean() {
	// TODO Auto-generated method stub
	ApprovedLoans approvedloans= new ApprovedLoans();
	
	System.out.println("Enter Application ID: ");
	approvedloans.setApplication_ID(sc.next());
	
	System.out.println("Enter Customer name : ");
	approvedloans.setCustomer_name(sc.next());
	
	System.out.println("Enter amount of loan granted : ");
	approvedloans.setAmountofloangranted(sc.nextDouble());
	
	System.out.println("Enter monthly installment : ");
	approvedloans.setMonthlyinstallment(sc.nextDouble());
	
	System.out.println("Enter years time period: ");
	approvedloans.setYearstimeperiod(sc.nextDouble());

	System.out.println("Enter downpayment : ");
	approvedloans.setDownpayment(sc.nextDouble());

	System.out.println("Enter rateofinterest : ");
	approvedloans.setRateofinterest(sc.nextDouble());

	System.out.println("Enter Status : ");
	approvedloans.setStatus(sc.next());
	
	System.out.println("Enter total amount payable : ");
	approvedloans.setTotalamountpayable(sc.nextDouble());

	try {
		Serviceimpl = new Serviceimp();

		Serviceimpl.insertApproved(approvedloans);
		return approvedloans;
	}catch (LoanException loanException) {
		logger.error("exception occured", loanException);
		System.err.println("Invalid data:");
		System.err.println(loanException.getMessage() + " \n Try again..");
		System.exit(0);
	}
	
	return null;
}



}



