package com.cg.loan.dao;

public interface IQueryMapper {
	//Admin
	public static final String DELETE_QUERY="Delete from LoanProgramsOffered where loan_id=?";
	public static final String INSERT_ADMIN="INSERT INTO ApprovedLoans VALUES(?,?,?,?,?,?,?,?,?)";
	
	//customer
	public static final String RETRIVE_ALL_QUERY="SELECT loan_id,Program_Name,description,type,durationinyears,min_loan_amount,max_loan_amount,rate_of_interest,proofs_required FROM LoanProgramsOffered";
	public static final String INSERT_QUERY="INSERT INTO LoanApplication VALUES(loan_seq.NEXTVAL,SYSDATE,?,?,?,?,?,?,?,'pending',SYSDATE+2,?)";
	public static final String INSERT_QUERY2="INSERT INTO CustomerDetails VALUES(loan_seq.CURRVAL,?,?,?,?,?,?)";
	public static final String DONARID_QUERY_SEQUENCE="SELECT loan_seq.CURRVAL FROM DUAL";
	public static final String SELECT_STATUS_LoanApplication="select status from loanapplication where application_id=?";
	
	//LAD
	
	public static final String Customer_Status_Update="UPDATE loanapplication SET Status=? WHERE Application_id=?";
	public static final String VIEW_CUSTOMER_DETAILS_QUERY="SELECT Applicant_name,date_of_birth ,marital_status ,mobile_number,CountofDependents,email_id  FROM CustomerDetails WHERE  Application_ID=?";
	public static final String SELECT_QUERY="SELECT Application_id,application_date,Loan_program,Amount_of_Loan,AddressofProperty,AnnualFamilyIncome,DocumentProofsAvailable,GuaranteeCover,MarketValueofGuaranteeCover,Status,Date_Of_Interview,loan_id  from loanapplication";
	
	
	}
//loan_id,Program_Name,description,type,durationinyears,min_loan_amount,max_loan_amount,rate_of_interest,proofs_required

//public static final String SELECT_LoanApplication="SELECT application_date,Loan_program,AmountofLoan,AddressofProperty,AnnualFamilyIncome,DocumentProofsAvailable,GuaranteeCover,MarketValueofGuaranteeCover,Status,loan_id from LoanApplication where Application_id=?";

/*public static final String RETRIVE_ALL_QUERY="SELECT loan_id,Program_Name,description,type,durationinyears,min_loan_amount,max_loan_amount,rate_of_interest,proofs_required FROM LoanProgramsOffered";
public static final String VIEW_DONAR_DETAILS_QUERY="SELECT Applicant_name,date_of_birth ,marital_status ,mobile_number,CountofDependents,email_id  FROM donor_details WHERE  Application_id=?";
public static final String INSERT_QUERY="INSERT INTO LoanApplication VALUES(loan_seq.NEXTVAL,SYSDATE,?,?,?,?,?,?,?,?,sysdate+2,?)";
public static final String INSERT_QUERY2="INSERT INTO CustomerDetails VALUES(?,?,?,?,?,?)";
public static final String DONARID_QUERY_SEQUENCE="SELECT loan_seq.CURRVAL FROM DUAL";
public static final String SELECT_STATUS_LoanApplication="SELECT Status from LoanApplication where loan_id=?";
public static final String SELECT_QUERY="SELECT * FROM LoanApplication WHERE loanId=?";
public static final String DELETE_QUERY="Delete from LoanProgramsOffered where LOAN_ID=?";
public static final String UPDATE_QUERY="update LoanProgramsOffered set loan_id=?,Program_Name=?,description=?,type=?,durationinyears=?,min_loan_amount=?,max_loan_amount=?,rate_of_interest=?,proofs_required=? where loanId=?";
public static final String SELECT_LoanApplication="SELECT application_date,Loan_program,AmountofLoan,AddressofProperty,AnnualFamilyIncome,DocumentProofsAvailable,GuaranteeCover,MarketValueofGuaranteeCover,Status,loan_id from LoanApplication where Application_id=?";*/
//public static final String VIEW_DONAR_DETAILS_QUERY="SELECT Applicant_name,date_of_birth ,marital_status ,mobile_number,CountofDependents,email_id  FROM donor_details WHERE  Application_id=?";