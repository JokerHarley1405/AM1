/**
 * 
 */
package com.cg.loan.dao;

import com.cg.loan.bean.Users;



/**
 * @author CAPG
 *
 */
public interface IUserDao {
	public Users getAuthentication(Users usersBean);
}
