package com.cg.loan.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;















import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanApplication;
import com.cg.loan.bean.LoanProgram;
import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;
import com.cg.loan.util.DBConnection;

public class DaoImp implements IDao{

	Logger logger=Logger.getRootLogger();
	public DaoImp()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	
	//Customer
	@Override
	public String applyForLoan(LoanApplication loanApp, Customer cust)
			throws LoanException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
		
		String appId=null;
		
		int queryResult=0;
		int queryResult1=0;
		
		try
		{		
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_QUERY);
			
			
			preparedStatement.setString(1,loanApp.getLoan_program());			
			preparedStatement.setDouble(2,loanApp.getAmountofLoan());
			preparedStatement.setString(3,loanApp.getAddressofProperty());
			preparedStatement.setDouble(4,loanApp.getAnnualFamilyIncome());
			preparedStatement.setString(5,loanApp.getDocumentProofsAvailable());
			preparedStatement.setString(6,loanApp.getGuaranteeCover());
			preparedStatement.setDouble(7,loanApp.getMarketValueofGuaranteeCover());
			preparedStatement.setInt(8, loanApp.getLoan_id());
			
			queryResult=preparedStatement.executeUpdate();
			
			preparedStatement1=connection.prepareStatement(IQueryMapper.INSERT_QUERY2);
			preparedStatement1.setString(1,cust.getApplicantName());
			preparedStatement1.setString(2,cust.getDob());
			preparedStatement1.setString(3,cust.getMarital_status());
			preparedStatement1.setString(4,cust.getMobile_number());
			preparedStatement1.setInt(5,cust.getCountofDependents());
			preparedStatement1.setString(6,cust.getEmailId());
		
			
			queryResult1=preparedStatement1.executeUpdate();
		
			preparedStatement = connection.prepareStatement(IQueryMapper.DONARID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				appId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new LoanException("Inserting donor details failed ");

			}
			else
			{
				logger.info("Donor details added successfully:");
				return appId;
			}

		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				//preparedStatement1.close();
				
				preparedStatement.close();
				preparedStatement1.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new LoanException("Error in closing db connection");

			}
		}
		
	}
		

		@Override
	public List<LoanProgram> viewAllLoan() throws LoanException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		//Boolean a=false;
		
		List<LoanProgram> loanlist=new ArrayList<LoanProgram>();
		try
		{
			ps=con.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
	
			while(resultset.next())
			{	
				LoanProgram bean=new LoanProgram();
				
				bean.setLoanId(resultset.getInt(1));
				bean.setProgramName(resultset.getString(2));
				bean.setDescription(resultset.getString(3));
				bean.setType(resultset.getString(4));
				bean.setDurationInYears(resultset.getDouble(5));
				bean.setMinLoanAmount(resultset.getDouble(6));
				bean.setMaxLoanAmount(resultset.getDouble(7));
				bean.setRateOfInterest(resultset.getDouble(8));
				bean.setProofsRequired(resultset.getString(9));
				loanlist.add(bean);
				donorCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new LoanException("Error in closing db connection");

			}
		}
		if( donorCount == 0)
			return null;
		else
			return loanlist;
	}


@Override
public LoanApplication viewLoanStatus(String applicationId) throws LoanException, SQLException, ClassNotFoundException {
			// TODO Auto-generated method stub
			Connection con=DBConnection.getInstance().getConnection();
			int donorCount = 0;
			PreparedStatement ps=null;
			ResultSet resultset = null;
			LoanApplication bean=null;
			try
			{
				ps=con.prepareStatement(IQueryMapper.SELECT_STATUS_LoanApplication);
				ps.setString(1,applicationId);
				resultset=ps.executeQuery();
		
				while(resultset.next())
				{	
					 bean=new LoanApplication();
					
					bean.setStatus(resultset.getString(1));
				}	
				if(bean != null)
				{
					logger.info("Record Found Successfully");
					return bean;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
				
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new LoanException("Tehnical problem occured. Refer log");
			}
			finally
			{
				try 
				{
					resultset.close();
					ps.close();
					con.close();
				}catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new LoanException("Error in closing db connection");

				} 
			}
		}
	
	
	



	
	//Admin
	
	@Override
	public void deleteLoanProgram(String loanId) throws LoanException {
		// TODO Auto-generated method stub

		PreparedStatement preparedStatement = null;
		
		try{
			Connection connection = DBConnection.getInstance().getConnection();	
			preparedStatement = connection.prepareStatement(IQueryMapper.DELETE_QUERY);
		//	preparedStatement = connection.prepareStatement("Delete from LoanProgramsOffered where loan_id=?");
			preparedStatement.setString(1, loanId);
			preparedStatement.executeUpdate();
			
			
			System.out.println("PROGRAM Deleted ::Thank you");
			logger.info("Program deleted successfully.");
		}catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured refer log");
		}

		
	
	}

	

	@Override
	public void update(String mod, int id1) throws LoanException {
		// TODO Auto-generated method stub
		Statement stmt=null;
		String sql;
		Connection connection = DBConnection.getInstance().getConnection();	
		ResultSet resultset = null;
		try {
			stmt = connection.createStatement();
			sql="update LoanProgramsOffered set".concat(mod).concat(" where loan_id='"+id1+"'");
			//preparedStatement = connection.prepareStatement("update LoanProgramsOffered set".concat(mod).concat("where loanId='"+id1+"'"));
			
			if(!mod.equals(""))
			{
				resultset= stmt.executeQuery(sql);
				System.out.println("Record Modified in LOAN DB ");
				logger.info("Record Modified in LOAN DB ");
			}
			
		}
	catch (SQLException e)
		{
		logger.error("Exception occured : "+ e.getMessage());
		System.out.println("Error Has Occured,Please Try Again");
		}	
		finally{
			try {
				resultset.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} //Closing database resources
			try {
				stmt.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return;
	}

	@Override
	public String insertApproved(ApprovedLoans apploan) throws LoanException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;
		
		int queryResult=0;
		
		
		try
		{		
			preparedStatement=connection.prepareStatement(IQueryMapper.INSERT_ADMIN);
			
			
			preparedStatement.setString(1,apploan.getApplication_ID());			
			preparedStatement.setString(2,apploan.getCustomer_name());
			preparedStatement.setDouble(3,apploan.getAmountofloangranted());
			preparedStatement.setDouble(4,apploan.getMonthlyinstallment());
			preparedStatement.setDouble(5,apploan.getYearstimeperiod());
			preparedStatement.setDouble(6,apploan.getDownpayment());
			preparedStatement.setDouble(7,apploan.getRateofinterest());
			preparedStatement.setString(8, apploan.getStatus());
			preparedStatement.setDouble(9, apploan.getTotalamountpayable());
			queryResult=preparedStatement.executeUpdate();


			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new LoanException("Inserting ADMIN details failed ");

			}
			else
			{
				logger.info("ADMIN INSERTION details added successfully:");
				return null;
			}

		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				
				preparedStatement.close();
				
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new LoanException("Error in closing db connection");

			}
		}
		

	}
	
	
	
	//LAD
	
	
	
	
	
	/*@Override
	public List<LoanProgram> viewAllLoan() throws LoanException {
			// TODO Auto-generated method stub
			Connection con=DBConnection.getInstance().getConnection();
			int donorCount = 0;
			PreparedStatement ps=null;
			ResultSet resultset = null;
			//Boolean a=false;		
			List<LoanProgram> loanlist=new ArrayList<LoanProgram>();
			try
			{
				ps=con.prepareStatement(IQueryMapper.RETRIVE_ALL_QUERY);
				resultset=ps.executeQuery();
	 
				while(resultset.next())
				{	
					LoanProgram bean=new LoanProgram();
					bean.setLoanId(resultset.getInt(1));
					bean.setProgramName(resultset.getString(2));
					bean.setDescription(resultset.getString(3));
					bean.setType(resultset.getString(4));
					bean.setDurationInYears(resultset.getDouble(5));
					bean.setMinLoanAmount(resultset.getDouble(6));
					bean.setMaxLoanAmount(resultset.getDouble(7));
					bean.setRateOfInterest(resultset.getDouble(8));
					bean.setProofsRequired(resultset.getString(9));
					loanlist.add(bean);
					donorCount++;
				}						
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new LoanException("Tehnical problem occured. Refer log");
			}
	 
			finally
			{
				try 
				{
					resultset.close();
					ps.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new LoanException("Error in closing db connection");
	 
				}
			}
			if( donorCount == 0)
				return null;
			else
				return loanlist;
		}*/
	@Override
	public List<LoanApplication> viewLoanbyID(String loanId)
			throws LoanException, SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		LoanApplication bean=null;
		 List<LoanApplication> list =new ArrayList<LoanApplication>();
		
		try
		{
			ps=con.prepareStatement("select Application_id,application_date,Loan_program,Amount_of_Loan,AddressofProperty,AnnualFamilyIncome,"
					+ "DocumentProofsAvailable,GuaranteeCover,MarketValueofGuaranteeCover, status from loanapplication where loan_id=?");
			ps.setString(1,loanId);
			resultset=ps.executeQuery();

			while(resultset.next())
			{	
				 bean=new LoanApplication();
				
				bean.setApplication_id(resultset.getString(1));
				bean.setApplication_date(resultset.getDate(2));
				bean.setLoan_program(resultset.getString(3));
				bean.setAmountofLoan(resultset.getDouble(4));
				bean.setAddressofProperty(resultset.getString(5));
				bean.setAnnualFamilyIncome(resultset.getDouble(6));
				bean.setDocumentProofsAvailable(resultset.getString(7));
				bean.setGuaranteeCover(resultset.getString(8));
				bean.setMarketValueofGuaranteeCover(resultset.getDouble(9));
				bean.setStatus(resultset.getString(10));
				list.add(bean);
			}	
			if(list != null)
			{
				logger.info("Record Found Successfully");
				return list;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured. Refer log");
		}
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			}catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new LoanException("Error in closing db connection");

			} 
		}

		

	}

	 
	/*@Override
	public List<LoanApplication> ViewForLoanApp()throws LoanException {
		// TODO Auto-generated method stub
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		PreparedStatement ps=null;
		ResultSet resultset = null;
		//Boolean a=false;		
		LoanApplication bean = null;
		List<LoanApplication> loanApplist=new ArrayList<LoanApplication>();
		try
		{
			ps=con.prepareStatement(IQueryMapper.SELECT_QUERY);
			resultset=ps.executeQuery();

			while(resultset.next())
			{	
				bean=new LoanApplication();
				bean.setApplication_id(resultset.getString(1));
				bean.setApplication_date(resultset.getDate(2));
				bean.setLoan_program(resultset.getString(3));
				bean.setAmountofLoan(resultset.getDouble(4));
				bean.setAddressofProperty(resultset.getString(5));
				bean.setAnnualFamilyIncome(resultset.getDouble(6));
				bean.setDocumentProofsAvailable(resultset.getString(7));
				bean.setGuaranteeCover(resultset.getString(8));
				bean.setMarketValueofGuaranteeCover(resultset.getDouble(9));
				bean.setStatus(resultset.getString(10));
				bean.setDate_Of_Interview(resultset.getDate(11));
				bean.setLoan_id(resultset.getInt(12));
				loanApplist.add(bean);
				donorCount++;
			}						
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new LoanException("Tehnical problem occured. Refer log");
		}

		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new LoanException("Error in closing db connection");

			}
		}
		if( donorCount == 0)
			return null;
		else
			return loanApplist;
	}*/
		
	@Override
	public Customer viewCustomerDetails(String applicationId) throws LoanException {
				// TODO Auto-generated method stub
				Connection con=DBConnection.getInstance().getConnection();
				PreparedStatement ps=null;
				ResultSet resultset = null;
				Customer bean = null;
	 
				try
				{
					ps=con.prepareStatement(IQueryMapper.VIEW_CUSTOMER_DETAILS_QUERY);
					ps.setString(1,applicationId);
					resultset=ps.executeQuery();
					if(resultset.next())
					{	
						bean = new Customer();
						bean.setApplicantName(resultset.getString(1));
						bean.setDob(resultset.getString(2));
						bean.setMarital_status(resultset.getString(3));
						bean.setMobile_number(resultset.getString(4));
						bean.setCountofDependents(resultset.getInt(5));
						bean.setEmailId(resultset.getString(6));
	 
					}			
				if(bean != null)
				{
					logger.info("Record Found Successfully");
					return bean;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new LoanException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultset.close();
					ps.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new LoanException("Error in closing db connection");
				}
			}
		}


	
	@Override
	public void updateLoanAppln(String mod, String id) throws LoanException {
		Statement stmt=null;
		String sql;
		Connection connection = DBConnection.getInstance().getConnection();	
		
		
		try 
		{	
			stmt = connection.createStatement();
		sql="update loanapplication set".concat(mod).concat(" where Application_id='"+id+"'");
			stmt.executeQuery(sql);
			System.out.println("Record Modified in LOAN DB ");
			logger.info("Record Modified in LOAN DB ");
		} 
		catch (Exception e) 
		{
			logger.error(e.getMessage());
			throw new LoanException("ERROR IN UPDATING COURSE DETAILS");

		}
		
	}
	
	
		
	}


	


	

