package com.cg.loan.dao;

/**
 * 
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;
import com.cg.loan.util.DBConnection;

/**
 * @author CAPG
 *
 */
public class UserDaoImpl implements IUserDao {

	Logger logger = Logger.getRootLogger();
	Connection con;

	/**
	 * @throws AirlineException
	 * @throws SQLException
	 * @throws NamingException
	 * 
	 */
	public UserDaoImpl() throws NamingException, SQLException, LoanException {
		// TODO Auto-generated constructor stub
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	@Override
	public Users getAuthentication(Users usersBean) {
		// TODO Auto-generated method stub
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			Connection connection = DBConnection.getInstance().getConnection();

			String query = "select role from users where  LOGINID='" + usersBean.getLogin_id()
					+ "' and PASSWORD='" + usersBean.getPassword() + "'";

			preparedStatement = connection.prepareStatement(query);
			resultSet = preparedStatement.executeQuery();
			// System.out.println(resultSet.getFetchSize());
			resultSet.next();
			// System.out.println(resultSet.getString(3));
			usersBean.setRole(resultSet.getString(1));
	
			logger.info("Admin is authenticated.");

		} catch (SQLException e) {
			// TODO Auto-generated catch block

		} catch (Exception e) {

		}
		return usersBean;
	}

	

	
}
