package com.cg.loan.bean;




public class Customer
{
	private String Application_id;
	private String applicantName;
	private String dob;
	private String  marital_status;
//	Marital marital_status;
	private String mobile_number;
	private int CountofDependents;
	private String emailId;
	
		
	
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	/*public String getMarital_status() {
		return this.marital_status.toString();
	}
	public void setMarital_status(String marital_status) {
		this.marital_status =Marital.valueOf(marital_status);
	}*/
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getApplication_id() {
		return Application_id;
	}
	public void setApplication_id(String application_id) {
		Application_id = application_id;
	}
	
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	
	
	public String getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}
	public int getCountofDependents() {
		return CountofDependents;
	}
	public void setCountofDependents(int countofDependents) {
		CountofDependents = countofDependents;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
	
}
