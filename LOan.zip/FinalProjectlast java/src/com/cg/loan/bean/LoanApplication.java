package com.cg.loan.bean;

import java.util.Date;


public class LoanApplication 
{

	private String Application_id;
	private Date application_date;
	private String Loan_program;
//	LoanProgrameum Loan_program;
	private Double AmountofLoan;
	private String AddressofProperty;
	private Double AnnualFamilyIncome;
	private String DocumentProofsAvailable;
	private String GuaranteeCover;
	private Double MarketValueofGuaranteeCover;
	private String Status;
	private Date Date_Of_Interview;
	private int loan_id;
	
	
	
	
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getLoan_program() {
		return Loan_program;
	}
	public void setLoan_program(String loan_program) {
		Loan_program = loan_program;
	}
	/*public String getLoan_program() {
		return this.Loan_program.toString();
	}
	public void setLoan_program(String loan_program) {
		Loan_program = LoanProgrameum.valueOf(loan_program);
	}*/
	public Date getDate_Of_Interview() {
		return Date_Of_Interview;
	}
	public void setDate_Of_Interview(Date date_Of_Interview) {
		Date_Of_Interview = date_Of_Interview;
	}
	public String getGuaranteeCover() {
		return GuaranteeCover;
	}
	public void setGuaranteeCover(String guaranteeCover) {
		GuaranteeCover = guaranteeCover;
	}
	public Double getMarketValueofGuaranteeCover() {
		return MarketValueofGuaranteeCover;
	}
	public void setMarketValueofGuaranteeCover(Double marketValueofGuaranteeCover) {
		MarketValueofGuaranteeCover = marketValueofGuaranteeCover;
	}
	
	public int getLoan_id() {
		return loan_id;
	}
	public void setLoan_id(int loan_id) {
		this.loan_id = loan_id;
	}
	public String getApplication_id() {
		return Application_id;
	}
	public void setApplication_id(String application_id) {
		Application_id = application_id;
	}
	public Date getApplication_date() {
		return application_date;
	}
	public void setApplication_date(Date application_date) {
		this.application_date = application_date;
	}
	
	public Double getAmountofLoan() {
		return AmountofLoan;
	}
	public void setAmountofLoan(Double amountofLoan) {
		AmountofLoan = amountofLoan;
	}
	public String getAddressofProperty() {
		return AddressofProperty;
	}
	public void setAddressofProperty(String addressofProperty) {
		AddressofProperty = addressofProperty;
	}
	public Double getAnnualFamilyIncome() {
		return AnnualFamilyIncome;
	}
	public void setAnnualFamilyIncome(Double annualFamilyIncome) {
		AnnualFamilyIncome = annualFamilyIncome;
	}
	public String getDocumentProofsAvailable() {
		return DocumentProofsAvailable;
	}
	public void setDocumentProofsAvailable(String documentProofsAvailable) {
		DocumentProofsAvailable = documentProofsAvailable;
	}
	
	
	
}
