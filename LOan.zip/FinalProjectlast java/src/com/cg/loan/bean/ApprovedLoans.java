package com.cg.loan.bean;

public class ApprovedLoans {

	private String Application_ID;
	private String Customer_name;
	private double amountofloangranted;
	private double monthlyinstallment;
	private double yearstimeperiod;
	private double downpayment;
	private double rateofinterest;
	private String Status;
	private double totalamountpayable;
	
	public String getApplication_ID() {
		return Application_ID;
	}
	public void setApplication_ID(String application_ID) {
		Application_ID = application_ID;
	}
	public String getCustomer_name() {
		return Customer_name;
	}
	public void setCustomer_name(String customer_name) {
		Customer_name = customer_name;
	}
	public double getAmountofloangranted() {
		return amountofloangranted;
	}
	public void setAmountofloangranted(double amountofloangranted) {
		this.amountofloangranted = amountofloangranted;
	}
	public double getMonthlyinstallment() {
		return monthlyinstallment;
	}
	public void setMonthlyinstallment(double monthlyinstallment) {
		this.monthlyinstallment = monthlyinstallment;
	}
	public double getYearstimeperiod() {
		return yearstimeperiod;
	}
	public void setYearstimeperiod(double yearstimeperiod) {
		this.yearstimeperiod = yearstimeperiod;
	}
	public double getDownpayment() {
		return downpayment;
	}
	public void setDownpayment(double downpayment) {
		this.downpayment = downpayment;
	}
	public double getRateofinterest() {
		return rateofinterest;
	}
	public void setRateofinterest(double rateofinterest) {
		this.rateofinterest = rateofinterest;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public double getTotalamountpayable() {
		return totalamountpayable;
	}
	public void setTotalamountpayable(double totalamountpayable) {
		this.totalamountpayable = totalamountpayable;
	}
	
	
	
	
	
	
}
