package com.cg.loan.service;

/**
 * 
 */


import com.cg.loan.bean.Users;

/**
 * @author CAPG
 *
 */
public interface IUserService {

	public Users getAuthentication(Users usersBean);

}
