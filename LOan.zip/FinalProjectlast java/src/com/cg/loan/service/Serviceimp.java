package com.cg.loan.service;

import java.sql.SQLException;
import java.util.ArrayList;


import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanApplication;
import com.cg.loan.bean.LoanProgram;
import com.cg.loan.bean.Users;
import com.cg.loan.dao.DaoImp;
import com.cg.loan.dao.IDao;
import com.cg.loan.exception.LoanException;

public class Serviceimp implements IService{

	
	IDao Loandao=new DaoImp();	
	
	//Customer
	@Override
	public String applyForLoan(LoanApplication loanApp, Customer cust)
			throws LoanException {
		// TODO Auto-generated method stub
		
		Loandao=new DaoImp();	
		String LoanSeq;
		LoanSeq= Loandao.applyForLoan(loanApp, cust);
		return LoanSeq; 

	}

	@Override
	public List<LoanProgram> viewAllLoan() throws LoanException {
		// TODO Auto-generated method stub
		Loandao=new DaoImp();
		List<LoanProgram> loanList=null;
		loanList=Loandao.viewAllLoan();
		return loanList;
	}

	@Override
	public LoanApplication viewLoanStatus(String applicationId) throws LoanException, SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Loandao=new DaoImp();
		LoanApplication bean=null;
		bean=Loandao.viewLoanStatus(applicationId);
		return bean;

	}
	
	public void validateloanapp(LoanApplication loanApp) throws LoanException
	{
		
		List<String> validationErrors = new ArrayList<String>();

		if(!(isValidLoan_prm(loanApp.getLoan_program()))) {
			validationErrors.add("\n Please Enter valid Loan_program Should be Greater Than 3 Characters and maximum 10 characters long! \n");
		}
		if(!(isValidAmountofloan(loanApp.getAmountofLoan()))) {
			validationErrors.add("\n Please Enter valid Amount....Should be in digit greater than 10000 \n");
		}
		if(!(isValidAddress(loanApp.getAddressofProperty()))) {
			validationErrors.add("\n Address Should Be Greater Than 3 Characters and maximum 10 characters long! \n");
		}
		if(!(isValidAnnualFamily(loanApp.getAnnualFamilyIncome()))) {
			validationErrors.add("\n Please Enter valid AnnualFamilyIncome \n");
		}
		if(!(isValidDocument(loanApp.getDocumentProofsAvailable()))) {
			validationErrors.add("\n DocumentProofs Should Be In Alphabets and minimum 3 characters and maximum 10 characters long! \n");
		}
		if(!(isValidGuaranteeCover(loanApp.getGuaranteeCover()))) {
			validationErrors.add("\n Please Enter valid GuaranteeCover In Alphabets and minimum 3 characters and maximum 10 characters long! \n");
		}
		if(!(isValidMarketValueofGuarantee(loanApp.getMarketValueofGuaranteeCover()))) {
			validationErrors.add("\n Market Value of GuaranteeCover Should be in digit and greater than 20000 \n");
		}
		
		if(!validationErrors.isEmpty())
			throw new LoanException(validationErrors +"");
	}

	
	
	private boolean isValidLoan_prm(String loan_program) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(loan_program);
		if(nameMatcher.find())
			return true;
		else
			return false;
	}

	private boolean isValidMarketValueofGuarantee(Double marketValueofGuaranteeCover) {
		// TODO Auto-generated method stub
		
		return (marketValueofGuaranteeCover>20000);
	}

	private boolean isValidGuaranteeCover(String guaranteeCover) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(guaranteeCover);
		if(nameMatcher.find())
			return true;
		else
			return false;
	
	}

	private boolean isValidDocument(String documentProofsAvailable) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(documentProofsAvailable);
		if(nameMatcher.find())
			return true;
		else
			return false;

	}

	private boolean isValidAnnualFamily(Double annualFamilyIncome) {
		// TODO Auto-generated method stub
		return (annualFamilyIncome>0);
	
	}

	private boolean isValidAddress(String addressofProperty) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(addressofProperty);
		if(nameMatcher.find())
			return true;
		else
			return false;
	
	}

	private boolean isValidAmountofloan(Double amountofLoan) {
		// TODO Auto-generated method stub
		
		return (amountofLoan>10000);
	}

	

	
public void validateCustomer(Customer cust) throws LoanException
	{
		List<String> validationErrors = new ArrayList<String>();
		
		if(!(isValidApptName(cust.getApplicantName()))) {
			validationErrors.add("\n Applicant Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
	
		/*if(!(isValidAppDOB(cust.getDob()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
	*/
		if(!(isValidEmailId(cust.getEmailId()))){
			validationErrors.add("\n Invalid Email Id.. \n");
		}
		
		if(!(isValidMarital(cust.getMarital_status()))){
			validationErrors.add("\n Invalid Email Id.. \n");
		}
		
		if(!(isValidmobile_number(cust.getMobile_number()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		if(!(isValidCountofDependents(cust.getCountofDependents()))){
			validationErrors.add("\n Please Enter valid count... \n");
		}
		if(!validationErrors.isEmpty())
			throw new LoanException(validationErrors +"");
		}
		
	private boolean isValidMarital(String marital_status) {
	
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(marital_status);
		if(nameMatcher.find())
			return true;
		else
			return false;
		}

	private boolean isValidCountofDependents(int countofDependents) {
		// TODO Auto-generated method stub
		
		return (countofDependents>0);
	}

	/*private boolean isValidAppDOB(String dob) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[1-31]{2}+/[1-12]{2}+/[0-9]{4}$");
		Matcher nameMatcher=namePattern.matcher(dob);
		if(nameMatcher.find())
			return true;
		else
			return false;
	}*/

	private boolean isValidmobile_number(String mobile_number) {
		// TODO Auto-generated method stub
		Pattern pattern= Pattern.compile("^[789][0-9]{9}$");
		Matcher matcher= pattern.matcher(mobile_number);
		if( matcher.find())
			return true;
		else
			return false;
		
	}

	private boolean isValidEmailId(String emailId) {
		// TODO Auto-generated method stub
		Pattern pattern = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$" ,Pattern.CASE_INSENSITIVE);
		Matcher matcher= pattern.matcher(emailId);
		if(matcher.find())
			return true;
		else
			return false;
	}

	private boolean isValidApptName(String applicantName) {
		// TODO Auto-generated method stub
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,10}$");
		Matcher nameMatcher=namePattern.matcher(applicantName);
		if(nameMatcher.find())
			return true;
		else
			return false;
	}
public boolean validateAppId(String appID) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,3}");
		Matcher idMatcher = idPattern.matcher(appID);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		

}
	
	
	
	
	//Admin
	

	@Override
	public void deleteLoanProgram(String loanId) throws LoanException {
		// TODO Auto-generated method stub
		 Loandao.deleteLoanProgram(loanId);
	}

	@Override
	public void update(String mod, int id1) throws LoanException {
		// TODO Auto-generated method stub
		 Loandao.update(mod,id1);
		
	}

	@Override
	public String insertApproved(ApprovedLoans apploan) throws LoanException {
		// TODO Auto-generated method stub
		return Loandao.insertApproved(apploan);
	}
	
	
	//lad
	
	
	@Override
	public List<LoanApplication> viewLoanbyID(String loanId) throws LoanException,
			SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
		Loandao=new DaoImp();
		
		return Loandao.viewLoanbyID(loanId);
		
		
	}
	@Override
	public void updateLoanAppln(String mod,String id) throws LoanException {
		// TODO Auto-generated method stub
		Loandao=new DaoImp();
		 Loandao.updateLoanAppln(mod, id);	
	}
	@Override
	public Customer viewCustomerDetails(String applicationId) throws LoanException {
		// TODO Auto-generated method stub
		Loandao=new DaoImp();	
		Customer LoanSeq=null;
		LoanSeq= Loandao.viewCustomerDetails(applicationId);
		return LoanSeq; 
	}
	
	
	
	

}
