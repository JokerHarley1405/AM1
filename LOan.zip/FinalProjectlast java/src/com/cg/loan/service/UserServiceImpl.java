package com.cg.loan.service;

/**
 * 
 */


import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.loan.bean.Users;
import com.cg.loan.dao.IUserDao;
import com.cg.loan.dao.UserDaoImpl;
import com.cg.loan.exception.LoanException;

/**
 * @author CAPG
 *
 */
public class UserServiceImpl implements IUserService {

	IUserDao iUserDao;

	/** 
	*/
	public UserServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Users getAuthentication(Users usersBean) {
		// TODO Auto-generated method stub
		try {
			iUserDao = new UserDaoImpl();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
		} catch (LoanException e) {
			// TODO Auto-generated catch block
			
		}
		return iUserDao.getAuthentication(usersBean);

	}

	

}
