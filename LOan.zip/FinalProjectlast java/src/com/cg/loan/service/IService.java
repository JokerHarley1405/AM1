package com.cg.loan.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.loan.bean.ApprovedLoans;
import com.cg.loan.bean.Customer;
import com.cg.loan.bean.LoanApplication;
import com.cg.loan.bean.LoanProgram;
import com.cg.loan.bean.Users;
import com.cg.loan.exception.LoanException;

public interface IService {
	

	
	
	public void update(String mod,int id1) throws LoanException;
	public void deleteLoanProgram(String loanId) throws LoanException;
	public String insertApproved(ApprovedLoans apploan) throws LoanException;
	//Customer
	public String applyForLoan(LoanApplication loanApp, Customer cust) throws LoanException;
	public List<LoanProgram> viewAllLoan() throws LoanException;
	public LoanApplication viewLoanStatus(String applicationId) throws LoanException, SQLException, ClassNotFoundException;
	
	//LAD
	
//	public boolean validateLogin(Users user) throws LoanException;
//	public List<LoanProgram> viewAllLoan() throws LoanException;//same in all characters
//	public List<LoanApplication> ViewForLoanApp() throws LoanException;
	public List<LoanApplication> viewLoanbyID(String loanId) throws LoanException, SQLException, ClassNotFoundException;
	public void updateLoanAppln(String mod1,String id1) throws LoanException;
	public Customer viewCustomerDetails(String applicationId) throws LoanException;
	
	
}
