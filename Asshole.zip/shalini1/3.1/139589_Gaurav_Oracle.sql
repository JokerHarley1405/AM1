CREATE OR REPLACE PROCEDURE guideDetails(v_gdname IN VARCHAR2(20))
IS
DECLARE
	CURSOR src_data IS SELECT * FROM CourseFeedback 
	WHERE guide_name='v_gdname' AND rating>8;
	v_record CourseFeedback%rowtype;
BEGIN
	open src_data;
	dbms_output.put_line('guide_name'||' '||'course_name'||' '||'subject_name'||' '||'rating');
	fetch src_data into v_record;
	loop
		exit when src_data%NOTFOUND;
		dbms_output.put_line(v_record.guide_name||' '||v_record.course_name||' '||v_record.subject_name||' '||v_record.rating);
	    fetch src_data into v_record;
	END LOOP;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN
		dbms_output.put_line('Guide name does not exist');
	close src_data;
END;
/