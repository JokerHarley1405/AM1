package com.cg.asm.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.asm.exception.AssetException;
import com.cg.asm.service.AssetServiceManagerImpl;
import com.cg.asm.service.IAssetServiceManager;

public class ManagerController {

	public void start() throws AssetException {
		try {
			System.out.println("Welcome to Manager Controller");
			int ch = 0;
			IAssetServiceManager service = new AssetServiceManagerImpl();

			Scanner sc = new Scanner(System.in);
			while (ch != 3) {
				System.out
						.println("1.Raise request for allocation of asset to an employee");
				System.out
						.println("2.View status of request based on AllocationID");
				System.out.println("3.Exit !!");
				System.out.println("Enter choice :");
				ch = sc.nextInt();
				switch (ch) {
				case 1:
					System.out.println("Enter employee number:");
					int empNo = sc.nextInt();
					System.out.println("Enter assetId");
					int assetId = sc.nextInt();
					try {
						int id = service.RaiseRequest(assetId, empNo);
						if (id > 0) {
							System.out
									.println("Request raised successfully  !!");
						}
					} catch (AssetException e) {
						// TODO Auto-generated catch block
						System.out.println("Exception : " + e.getMessage());
					}
					break;

				case 2:
					System.out.println("Enter the Allocation ID: ");
					int id = sc.nextInt();
					try {
						String status = service.getStatusById(id);
						if (status != null) {
							System.out.println("\nAllocation Id=" + id
									+ "\nStatus= " + status);
						} else {
							System.out
									.println("Entered ID does not exists please enter the correct allocation ID !!");
						}
					} catch (AssetException e) {

						System.out.println("Exception : " + e.getMessage());
					}
					break;

				case 3:
					System.out.println("Exiting application  !!");
					break;

				default:
					System.out.println("Enter valid option !!");
					break;
				}
			}
			sc.close();
		} catch (InputMismatchException e) {
			System.out.println("Exception : "+e.getMessage());
		}
	}
}
