package com.cg.asm.ui;

import java.util.Scanner;

import com.cg.asm.entities.UserMaster;
import com.cg.asm.exception.AssetException;
import com.cg.asm.service.AssetServiceImpl;
import com.cg.asm.service.IAssetService;

public class Main {

	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		IAssetService service = new AssetServiceImpl();
		AdminController ac = new AdminController();
		ManagerController mc = new ManagerController();
		String username = "";
		String password = "";
		UserMaster user = new UserMaster();
		System.out.println("Enter user name : ");
		username = sc1.nextLine();
		System.out.println("Enter password : ");
		password = sc1.nextLine();
		try {
			user = service.findLoginType(username, password);
			if (user != null) {
				if (user.getUserType().equalsIgnoreCase("admin")) {
					ac.start();
				} else
					mc.start();
			} else {
				System.out.println("Incorrect Username/Password");
			}

		} catch (AssetException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception : " + e.getMessage());
		}
		sc1.close();

	}
}
