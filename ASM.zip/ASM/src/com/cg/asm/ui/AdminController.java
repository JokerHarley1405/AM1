package com.cg.asm.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.asm.entities.Asset;
import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.exception.AssetException;
import com.cg.asm.service.AssetServiceImpl;
import com.cg.asm.service.IAssetService;

public class AdminController {

	public void start() throws AssetException {
		try {
			System.out.println("Welcome to Admin Controller\n");
			IAssetService service = new AssetServiceImpl();
			AssetServiceImpl assetService = new AssetServiceImpl();
			int ch = 0;
			Scanner sc = new Scanner(System.in);
			while (ch != 5) {
				System.out.println("\n1.Add asset");
				System.out.println("2.Modify assets");
				System.out.println("3.Request updation");
				System.out.println("4.Generate reports");
				System.out.println("5.Exit !!\n");
				System.out.println("Enter option");
				ch = sc.nextInt();
				int quantity = 0;
				switch (ch) {
				case 1:
					try {
						int add = 0;
						Asset asset = new Asset();
						System.out.println("Enter Asset details");
						System.out.println("Enter Asset ID");
						int assetId = sc.nextInt();

						if (service.viewAsset(assetId) == null) {
							System.out.println("Enter Asset Name");
							String assetName = sc.next();
							sc.nextLine();
							System.out.println("Enter Asset Description");
							String assetDes = sc.nextLine();
							// sc.nextLine();
							System.out.println("Enter Quantity");
							quantity = sc.nextInt();
							asset.setAssetId(assetId);
							asset.setAssetName(assetName);
							asset.setAssetDesc(assetDes);
							asset.setQuantity(quantity);

							assetService.validateAsset(asset);

							add = service.addAsset(asset);
							if (add > 0) {
								System.out
										.println("Asset details added successfully !!");
							}
						} else {
							System.out
									.println("Asset with ID already exists !!");
						}
					} catch (InputMismatchException e) {
						throw new AssetException("Invalid input !!");
					} catch (AssetException e) {
						System.out.println("Exception : " + e.getMessage());
					}

					break;
				case 2:
					int choice = 0;

					try {
						while (choice != 4) {
							System.out.println("\n1.Modify Asset Name");
							System.out.println("2.Modify Asset Description");
							System.out.println("3.Modify Asset Quantity");
							System.out.println("4.Exit\n");
							System.out.println("Enter choice : ");
							choice = sc.nextInt();

							int id = 0;
							int update = 0;
							Asset as;
							switch (choice) {
							case 1:
								System.out.println("Enter Asset Id ");
								id = sc.nextInt();
								as = service.viewAsset(id);
								if (as != null) {
									sc.nextLine();
									System.out.println("Enter Asset name");
									String name = sc.nextLine();
									while (!assetService.validName(name)) {
										System.out
												.println("Enter proper asset name");
										name = sc.nextLine();

									}
									update = service.updateName(id, name);
									if (update > 0) {
										System.out
												.println("Asset name updated successfully !!");
									} else {
										System.out
												.println("Asset with given ID does not exists");
									}
								}

								break;

							case 2:
								System.out.println("Enter Asset Id ");
								id = sc.nextInt();
								as = service.viewAsset(id);
								if (as != null) {
									sc.nextLine();
									System.out
											.println("Enter Asset Description");
									String desc = sc.nextLine();

									while (!assetService.validDesc(desc)) {
										System.out
												.println("Enter proper description, it should not contain special characters");
										desc = sc.nextLine();
									}

									update = service.updateDesc(id, desc);
									if (update > 0)
										System.out
												.println("Asset description updated successfully !!");
								} else {
									System.out
											.println("Asset with given ID does not exists");
								}
								break;

							case 3:
								System.out.println("Enter Asset Id ");
								id = sc.nextInt();
								as = service.viewAsset(id);
								if (as != null) {
									sc.nextLine();
									System.out.println("Enter Asset Quantity");
									quantity = sc.nextInt();

									update = service.updateQuantity(id,
											quantity);
									if (update > 0) {
										System.out
												.println("Asset quantity updated successfully !!");
									} else {
										System.out
												.println("Asset with given ID does not exists");
									}

								}
								break;

							case 4:
								System.out
										.println("Returning back to main menu !! ");
								// System.exit(0);
								break;

							default:
								System.out
										.println("Please enter available choice !!");
								break;
							}// end of inner switch
						}
					} catch (InputMismatchException e) {
						throw new AssetException("Invalid input !!");
					} catch (AssetException e2) {
						// TODO Auto-generated catch block
						System.out.println("Exception : " + e2.getMessage());
					}
					// end of inner while

					break;

				case 3:
					int c = 0;
					try {
						List<AssetAllocation> list = service
								.viewAllUnApprovedRequests();
						if (!list.isEmpty()) {
							System.out.println("List of raised Requests are:");
							for (AssetAllocation asset1 : list) {
								System.out.println(asset1.toString());
							}
							while (c != 2) {
								System.out
										.println("\n1.Enter Allocation Id to Approve/Reject");
								System.out.println("2.Exit\n");
								System.out.println("Enter Choice");
								c = sc.nextInt();
								switch (c) {
								case 1:
									System.out.println("Enter Allocation ID");
									AssetAllocation allocation = new AssetAllocation();
									int allocationId = sc.nextInt();
									if (assetService.validId(allocationId)) {
										allocation = service
												.viewAllocationDetails(allocationId);
										System.out.println(allocation
												.toString());
									} else {

									}
									break;

								case 2:
									System.out
											.println("Going back to home page !!");
									break;

								default:
									System.out.println("Enter valid choice !!");
									break;
								}
							}
						} else {
							System.out
									.println("There are no raised requests!!!!");
						}
					} catch (InputMismatchException e) {
						throw new AssetException("Invalid input !!");
					} catch (AssetException e) {

						System.out.println("Exception : " + e.getMessage());
					}
					break;

				case 4:
					try {
						System.out.println("\nAllocated list");
						List<AssetAllocation> list = service
								.ViewStatusApproved();
						if (!list.isEmpty()) {
							for (AssetAllocation asset2 : list) {
								System.out.println(asset2.toString());
							}
						} else {
							System.out.println("Allocated List is empty !!");
						}
						System.out.println("\nUnallocated list");
						List<AssetAllocation> list1 = service
								.ViewStatusUnapproved();
						if (!list.isEmpty()) {
							for (AssetAllocation asset1 : list1) {
								System.out.println(asset1.toString());
							}
						} else {
							System.out.println("Unallocated List is empty !!");
						}
					} catch (InputMismatchException e) {
						throw new AssetException("Invalid input !!");
					} catch (AssetException e1) {
						System.out.println("Exception : " + e1.getMessage());
					}
					break;

				case 5:
					System.out.println("\nExiting application !!!!!!!");
					break;

				default:
					System.out.println("\nEnter valid choice !!!!");
					break;
				}
			}
			sc.close();
		} catch (InputMismatchException e) {
			throw new AssetException("Input is invalid !!");
		} catch (AssetException e) {
			System.out.println("Exception : " + e.getMessage());
		}
	}
}
