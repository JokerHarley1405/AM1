package com.cg.asm.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.asm.exception.AssetException;


public class DBConnection {

	public static Connection getConnection() throws AssetException
	{
		Connection con;
		try {
			con = null;
			Properties prop = new Properties();
			FileReader fr = new FileReader("resources/jdbc.properties");
			prop.load(fr);
			
			//String drive = prop.getProperty("drive");
			String url = prop.getProperty("url") ;
			String username = prop.getProperty("username");
			String password = prop.getProperty("password");
			con = DriverManager.getConnection(url, username, password);
		} catch (FileNotFoundException e) {
			throw new AssetException("jdbc.properties file not found");
		} catch (IOException e) {
			throw new AssetException("Unable to read jdbc properties");
		} catch (SQLException e) {
			throw new AssetException("Database connection failed"+e.getMessage());
		}
		return con;
	}
}
