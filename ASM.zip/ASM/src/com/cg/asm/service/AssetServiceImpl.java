package com.cg.asm.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.asm.dao.AssetDaoImpl;
import com.cg.asm.dao.IAssetDao;
import com.cg.asm.entities.Asset;
import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.entities.UserMaster;
import com.cg.asm.exception.AssetException;

public class AssetServiceImpl implements IAssetService{
	IAssetDao dao = new AssetDaoImpl();
	@Override
	public UserMaster findLoginType(String uname, String pwd) throws AssetException {
		UserMaster userMaster = null;
		if(validLogin(uname, pwd))
		{
			 userMaster = dao.findLoginType(uname.toLowerCase(), pwd);
		}
		return userMaster;
	}

	@Override
	public int addAsset(Asset asset) throws AssetException {
		// TODO Auto-generated method stub
		
		return dao.addAsset(asset);
	}

	@Override
	public int updateName(int id, String name) throws AssetException {
		// TODO Auto-generated method stub
		return dao.updateName(id, name);
	}

	@Override
	public int updateDesc(int id, String desc) throws AssetException {
		// TODO Auto-generated method stub
		return dao.updateDesc(id, desc);
	}

	@Override
	public int updateQuantity(int id, int quantity) throws AssetException {
		// TODO Auto-generated method stub
		return dao.updateQuantity(id, quantity);
	}

	@Override
	public List<AssetAllocation> ViewStatusApproved() throws AssetException {
		// TODO Auto-generated method stub
		return dao.ViewStatusApproved();
	}

	@Override
	public List<AssetAllocation> ViewStatusUnapproved() throws AssetException {
		// TODO Auto-generated method stub
		return dao.ViewStatusUnapproved();
	}

	@Override
	public List<AssetAllocation> viewAllUnApprovedRequests()
			throws AssetException {
		// TODO Auto-generated method stub
		return dao.viewAllUnApprovedRequests();
	
	}

	@Override
	public AssetAllocation viewAllocationDetails(int allocationId)
			throws AssetException {
		// TODO Auto-generated method stub
		return dao.viewAllocationDetails(allocationId);
	}

	@Override
	public Asset viewAsset(int assetId) throws AssetException {
		// TODO Auto-generated method stub
		return dao.viewAsset(assetId);
	}

	public boolean validLogin(String username, String password)
	{
		boolean flag1 = false;
		
		Pattern pattern =Pattern.compile( "[A-Za-z\\s]*");
		Matcher matcher  = pattern.matcher(username);
		flag1 = matcher.matches();

		return flag1;
	}

	public boolean validId(int id)
	{
		boolean flag = false;
		String id1 = ""+id;
		Pattern pattern =Pattern.compile( "[0-9]*");
		Matcher matcher  = pattern.matcher(id1);
		flag = matcher.matches();
		return flag;
	}
	
	public boolean validName(String name)
	{
		boolean flag = false;
		Pattern pattern =Pattern.compile( "[A-Za-z0-9\\s]*");
		Matcher matcher  = pattern.matcher(name);
		flag = matcher.matches();
		return flag;
	}
	
	public boolean validQuantity(int quantity)
	{
		boolean flag = false;
		String q = ""+quantity;
		Pattern pattern =Pattern.compile( "[0-9]*");
		Matcher matcher  = pattern.matcher(q);
		flag = matcher.matches();
		return flag;
	}
	
	public boolean validDesc(String desc)
	{
		boolean flag = false;
		Pattern pattern =Pattern.compile( "[A-Za-z0-9\\s]*");
		Matcher matcher  = pattern.matcher(desc);
		flag = matcher.matches();
		return flag;
	}
	
	public boolean validateAsset(Asset asset) throws AssetException
	{
		boolean flag = false;
		String error = "";
		if(!validId(asset.getAssetId()))
			error="ID should be integer";
		if(!validName(asset.getAssetName()))
			error = "Name is not proper cannot contain special characters";
		if(!validQuantity(asset.getQuantity()))
			error = "Quantity must be only numbers !!";
		if(!validDesc(asset.getAssetDesc()))
			error="Description should not contain special characters";
		if(!error.isEmpty())
			throw new AssetException(error);
		return flag;
	}
}
