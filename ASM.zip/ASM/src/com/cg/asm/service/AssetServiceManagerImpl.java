package com.cg.asm.service;

import com.cg.asm.dao.AssetDaoManagerImpl;
import com.cg.asm.dao.IAssetDaoManager;
import com.cg.asm.exception.AssetException;

public class AssetServiceManagerImpl implements IAssetServiceManager {
	IAssetDaoManager dao = new AssetDaoManagerImpl() ;

	@Override
	public int RaiseRequest(int assetId, int empNo) throws AssetException {
		// TODO Auto-generated method stub
		return dao.RaiseRequest(assetId, empNo);
	}

	@Override
	public String getStatusById(int AllocationId) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getStatusById(AllocationId);
	}
	
}
