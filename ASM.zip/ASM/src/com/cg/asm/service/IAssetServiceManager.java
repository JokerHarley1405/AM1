package com.cg.asm.service;

import com.cg.asm.exception.AssetException;

public interface IAssetServiceManager {

	public int RaiseRequest(int assetId,int empNo)throws AssetException;
	public String getStatusById(int AllocationId) throws AssetException;
}
