package com.cg.asm.dao;

import com.cg.asm.exception.AssetException;

public interface IAssetDaoManager {
	
	public int RaiseRequest(int assetId, int empNo) throws AssetException;

	public String getStatusById(int AllocationId) throws AssetException;
}
