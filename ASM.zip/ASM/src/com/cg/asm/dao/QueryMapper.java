package com.cg.asm.dao;

public interface QueryMapper {

	public static final String SELECT_USER = "SELECT UserId, UserName, UserPassword, UserType FROM User_Master WHERE UserName = ? AND UserPassword = ? ";
	 
	public static final String SELECT_ASSET ="SELECT assetid,assetname,assetdes,quantity from asset where assetid = ?";
	public static final String INSERT_QUERY="insert into asset(assetid,assetname,assetdes,quantity) values(?,?,?,?)";
	public static final String UPDATE_NAME="update asset set assetname=? where assetid=?";
	public static final String UPDATE_DESC="update asset set assetdes=? where assetid=?";
	public static final String UPDATE_QUANTITY="update asset set quantity=? where assetid=?";
	
	public static final String REQUEST_APPROVED="select AllocationId,AssetId,Empno,Allocation_Date,Release_Date,Status from Asset_Allocation where Status='approved'";
	public static final String REQUEST_UNAPPROVED="select AllocationId,AssetId,Empno,Allocation_Date,Release_Date,Status from Asset_Allocation where Status='rejected'";

	public static final String VIEW_UNAPPROVED_REQUESTS="select AllocationId,AssetId,Empno,Allocation_Date,Release_Date,Status  from Asset_Allocation where Status='Unapproved' ";
	public static final String SELECT_ALLOCATION="select AllocationId,AssetId,Empno,Allocation_Date,Release_Date,Status  from Asset_Allocation where AllocationId=? ";
	public static final String SELECT_QUANTITY="select quantity from asset where AssetId=?";
	public static final String UPDATE_STATUS1="update Asset_Allocation set Status='approved',Release_Date=sysdate where AllocationId=?" ;
	public static final String UPDATE_STATUS2="update Asset_Allocation set Status='rejected',Release_Date=sysdate where AllocationId=?";

}
