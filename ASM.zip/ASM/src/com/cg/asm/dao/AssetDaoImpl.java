package com.cg.asm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.asm.entities.Asset;
import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.entities.UserMaster;
import com.cg.asm.exception.AssetException;
import com.cg.asm.util.DBConnection;

public class AssetDaoImpl implements IAssetDao {
	private Logger log = Logger.getLogger(AssetDaoImpl.class);

	public AssetDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public UserMaster findLoginType(String uname, String pwd)
			throws AssetException {
		UserMaster user = new UserMaster();
		log.info("Login with user credentials");
		Connection connection = DBConnection.getConnection();
		String query = QueryMapper.SELECT_USER;
		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, uname);
			ps.setString(2, pwd);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				log.info("Login Success");
				user.setUserId(rs.getString(1));
				user.setUserName(rs.getString(2));
				user.setUserPassword(rs.getString(3));
				user.setUserType(rs.getString(4));
			} else {
				user = null;
				log.error("Invalid Username/Password");
			}
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException("Sql exception : " + e.getMessage());

		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				log.error("SQL Exception" + e.getMessage());
				e.printStackTrace();
			}
		}

		return user;
	}

	@Override
	public int addAsset(Asset asset) throws AssetException {
		// TODO Auto-generated method stub
		int id = 0;
		log.info("Entering Add Asset Function");
		Connection con = DBConnection.getConnection();
		try {

			PreparedStatement pstmt = con
					.prepareStatement(QueryMapper.INSERT_QUERY);
			pstmt.setInt(1, asset.getAssetId());
			pstmt.setString(2, asset.getAssetName());
			pstmt.setString(3, asset.getAssetDesc());
			pstmt.setInt(4, asset.getQuantity());
			id = pstmt.executeUpdate();
			if (id <= 0) {
				log.error("Asset Details Insertion Failed");
				throw new AssetException("INSERT ASSET DETAILS FAILED");
			}
			log.info("Asset Details added successfully");

		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured in adding details : "
							+ e.getMessage());
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				log.error("Exception" + e.getMessage());
				throw new AssetException(e.getMessage());
			}
		}
		return id;
	}

	@Override
	public int updateName(int id, String name) throws AssetException {
		// TODO Auto-generated method stub
		int update = 0;
		log.info("Entering Update Asset Name Function");
		Connection con = DBConnection.getConnection();
		try {
			con = DBConnection.getConnection();
			PreparedStatement pstmt = con
					.prepareStatement(QueryMapper.UPDATE_NAME);
			pstmt.setString(1, name);
			pstmt.setInt(2, id);
			update = pstmt.executeUpdate();
			if (update <= 0) {
				log.error("Updation of Asset Name failed");
				throw new AssetException("Could not update asset name!! ");
			}
			log.info("Updation of Asset Name success");
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while updating name : "
							+ e.getMessage());
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				log.error("Exception" + e.getMessage());
				throw new AssetException(e.getMessage());
			}
		}
		return update;
	}

	@Override
	public int updateDesc(int id, String desc) throws AssetException {
		// TODO Auto-generated method stub
		int update = 0;
		log.info("Entering Update Asset Description Function");
		Connection con = DBConnection.getConnection();
		try {
			con = DBConnection.getConnection();
			PreparedStatement pstmt = con
					.prepareStatement(QueryMapper.UPDATE_DESC);
			pstmt.setString(1, desc);
			pstmt.setInt(2, id);
			update = pstmt.executeUpdate();
			if (update <= 0) {
				log.error("Updation of Asset Description failed");
				throw new AssetException(
						"Could not update Asset description !!");
			}
			log.info("Updation of Asset Description success");
		} catch (SQLException e) {
			log.error("Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while updating asset description : "
							+ e.getMessage());
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				log.error("Exception" + e.getMessage());
				throw new AssetException(e.getMessage());
			}
		}
		return update;
	}

	@Override
	public int updateQuantity(int id, int quantity) throws AssetException {
		// TODO Auto-generated method stub
		int update = 0;
		log.info("Entering Update Asset Quantity Function");
		Connection con = DBConnection.getConnection();
		try {
			con = DBConnection.getConnection();
			PreparedStatement pstmt = con
					.prepareStatement(QueryMapper.UPDATE_QUANTITY);
			pstmt.setInt(1, quantity);
			pstmt.setInt(2, id);
			update = pstmt.executeUpdate();
			if (update <= 0) {
				log.error("Updation of Asset Quantity failed");
				throw new AssetException("Could not update Asset quantity!!");
			}
			log.info("Updation of Asset Quantity success");
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while updating asset quantity : "
							+ e.getMessage());
		} finally {
			try {
				con.close();
			} catch (Exception e) {
				log.error("Exception" + e.getMessage());
				throw new AssetException(e.getMessage());
			}
		}
		return update;
	}

	@Override
	public List<AssetAllocation> ViewStatusApproved() throws AssetException {
		// TODO Auto-generated method stub
		List<AssetAllocation> list;
		log.info("Entering ViewStatusApproved Function");
		try {
			list = new ArrayList<AssetAllocation>();
			Connection con = DBConnection.getConnection();
			String query = QueryMapper.REQUEST_APPROVED;
			PreparedStatement pstmt = con.prepareStatement(query);
			ResultSet rst = pstmt.executeQuery();

			while (rst.next()) {
				AssetAllocation asset = new AssetAllocation();
				asset.setAllocationId(rst.getInt("AllocationId"));
				asset.setAssetId(rst.getInt("AssetId"));
				asset.setEmpNo(rst.getInt("Empno"));
				asset.setAllocationDate(rst.getDate("Allocation_Date"));
				asset.setReleaseDate(rst.getDate("Release_Date"));
				asset.setStatus(rst.getString("Status"));
				list.add(asset);
			}
			if (list.isEmpty())
				log.info("No details found for approved status");
			else
				log.info("Retrieving all approved status details");
			con.close();
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while viewing allocated list : "
							+ e.getMessage());
		}
		return list;
	}

	@Override
	public List<AssetAllocation> ViewStatusUnapproved() throws AssetException {
		// TODO Auto-generated method stub
		List<AssetAllocation> list;
		log.info("Entering ViewStatusUnApproved Function");
		try {
			list = new ArrayList<AssetAllocation>();
			Connection con = DBConnection.getConnection();
			String query1 = QueryMapper.REQUEST_UNAPPROVED;
			PreparedStatement pstmt = con.prepareStatement(query1);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				AssetAllocation asset = new AssetAllocation();
				asset.setAllocationId(rst.getInt("AllocationId"));
				asset.setAssetId(rst.getInt("AssetId"));
				asset.setEmpNo(rst.getInt("Empno"));
				asset.setAllocationDate(rst.getDate("Allocation_Date"));
				asset.setReleaseDate(rst.getDate("Release_Date"));
				asset.setStatus(rst.getString("Status"));
				list.add(asset);
			}
			if (list.isEmpty())
				log.info("No details found for unapproved status");
			else
				log.info("Retrieving all unapproved status details");
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while viewing unallocated list : "
							+ e.getMessage());
		}
		return list;
	}

	@Override
	public List<AssetAllocation> viewAllUnApprovedRequests()
			throws AssetException {
		// TODO Auto-generated method stub
		List<AssetAllocation> list = new ArrayList<AssetAllocation>();
		log.info("Entering ViewAllUnApprovedRequests Function");

		try {
			Connection con = DBConnection.getConnection();
			String qry = QueryMapper.VIEW_UNAPPROVED_REQUESTS;
			PreparedStatement pstmt = con.prepareStatement(qry);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {
				AssetAllocation asset = new AssetAllocation();

				asset.setAllocationId(rst.getInt("AllocationId"));
				asset.setAssetId(rst.getInt("AssetId"));
				asset.setEmpNo(rst.getInt("Empno"));
				asset.setAllocationDate(rst.getDate("Allocation_Date"));
				asset.setReleaseDate(rst.getDate("Release_Date"));
				asset.setStatus(rst.getString("Status"));

				list.add(asset);
			}
			if (list.isEmpty())
				log.info("No details found for unapproved requests");
			else
				log.info("Retrieving all unapproved requests");
			con.close();
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception while viewing the raised requests : "
							+ e.getMessage());
		}

		return list;
	}

	@Override
	public AssetAllocation viewAllocationDetails(int allocationId)
			throws AssetException {
		// TODO Auto-generated method stub
		AssetAllocation asset = new AssetAllocation();
		log.info("Entering viewAllocationDetails Function");
		int assetId = 0;
		int quantity = 0;
		try {
			Connection con = DBConnection.getConnection();
			String qry = QueryMapper.SELECT_ALLOCATION;
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, allocationId);
			ResultSet rst = pstmt.executeQuery();
			if (rst.next()) {
				asset.setAllocationId(rst.getInt("AllocationId"));
				asset.setAssetId(rst.getInt("AssetId"));
				asset.setEmpNo(rst.getInt("Empno"));
				asset.setAllocationDate(rst.getDate("Allocation_Date"));
				asset.setReleaseDate(rst.getDate("Release_Date"));
				asset.setStatus(rst.getString("Status"));
				log.info("Allocation details found");
			}
			assetId = asset.getAssetId();
			pstmt = con.prepareStatement(QueryMapper.SELECT_QUANTITY);
			pstmt.setInt(1, assetId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				log.info("Fetching details of quantity");
				quantity = rst.getInt("quantity");
				if (quantity > 0) {
					pstmt = con.prepareStatement(QueryMapper.UPDATE_QUANTITY);
					pstmt.setInt(1, quantity - 1);
					pstmt.setInt(2, assetId);
					pstmt.executeUpdate();
					pstmt = con.prepareStatement(QueryMapper.UPDATE_STATUS1);
					pstmt.setInt(1, allocationId);
					pstmt.executeUpdate();
					log.info("Updating status from unapproved to approved");
				} else {
					PreparedStatement pstmt1 = con
							.prepareStatement(QueryMapper.UPDATE_STATUS2);
					pstmt1.setInt(1, allocationId);
					pstmt1.executeUpdate();
					log.info("Updating status from unapproved to rejected");
				}
			}
			qry = QueryMapper.SELECT_ALLOCATION;
			pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, allocationId);
			rst = pstmt.executeQuery();
			if (rst.next()) {
				asset.setAllocationId(rst.getInt("AllocationId"));
				asset.setAssetId(rst.getInt("AssetId"));
				asset.setEmpNo(rst.getInt("Empno"));
				asset.setAllocationDate(rst.getDate("Allocation_Date"));
				asset.setReleaseDate(rst.getDate("Release_Date"));
				asset.setStatus(rst.getString("Status"));
			}
			con.close();
		} catch (SQLException e) {
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException(
					"SQL Exception occured while approving requests : "
							+ e.getMessage());
		}
		return asset;
	}

	@Override
	public Asset viewAsset(int assetId) throws AssetException {
		// TODO Auto-generated method stub
		Asset asset = new Asset();
		log.info("Entering viewAsset details Function");
		Connection con = DBConnection.getConnection();
		String qry = QueryMapper.SELECT_ASSET;
		try {
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, assetId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				asset.setAssetId(rs.getInt(1));
				asset.setAssetName(rs.getString(2));
				asset.setAssetDesc(rs.getString(3));
				asset.setQuantity(rs.getInt(4));

			} else {
				asset = null;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error("SQL Exception" + e.getMessage());
			throw new AssetException("SQL Exception : " + e.getMessage());
		}
		return asset;
	}

}
