package com.cg.asm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.exception.AssetException;
import com.cg.asm.util.DBConnection;

public class AssetDaoManagerImpl implements IAssetDaoManager {

	@Override
	public int RaiseRequest(int assetId, int empNo) throws AssetException {
		// TODO Auto-generated method stub
		Connection con = DBConnection.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		int id = 0;
		try {
			ps = con.prepareStatement(QueryMapperManager.SELECT_EMPLOYEE);
			ps.setInt(1, empNo);
			rs = ps.executeQuery();
			if (!rs.next())
				throw new AssetException("Employee doesnot exists !!");

			ps = con.prepareStatement(QueryMapperManager.SELECT_ASSET);
			ps.setInt(1, assetId);
			rs = ps.executeQuery();
			if (!rs.next())
				throw new AssetException(
						"Asset with entered ID does not exists");

			String query = QueryMapperManager.RAISE_REQUEST;

			ps = con.prepareStatement(query);
			ps.setInt(1, assetId);
			ps.setInt(2, empNo);
			id = ps.executeUpdate();
			if (id <= 0) {
				throw new AssetException("Failed to raise a request !!");
			}
		} catch (SQLException e) {
			throw new AssetException("SQL Exception : " + e.getMessage());
		}
		return id;
	}

	@Override
	public String getStatusById(int AllocationId) throws AssetException {
		// TODO Auto-generated method stub
		AssetAllocation allo_bean = new AssetAllocation();
		String status = null;
		try {
			Connection connection = DBConnection.getConnection();
			PreparedStatement pstmt = connection
					.prepareStatement(QueryMapperManager.SELECT_STATUS_BY_ID);
			pstmt.setInt(1, AllocationId);
			ResultSet resultset = pstmt.executeQuery();
			if (resultset.next()) {
				allo_bean.setStatus(resultset.getString(1));
			}
			if (allo_bean != null) {
				status = allo_bean.getStatus();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new AssetException("SQL Exception : " + e.getMessage());
		}
		return status;
	}
}
