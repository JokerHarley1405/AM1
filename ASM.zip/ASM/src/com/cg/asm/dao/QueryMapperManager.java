package com.cg.asm.dao;

public interface QueryMapperManager {

	public static final String RAISE_REQUEST="insert into asset_allocation(AllocationId,assetId,empNo,Allocation_date,Release_Date,status) values(assetseq.nextval,?,?,sysdate,null,'Unapproved')";
	public static final String SELECT_STATUS_BY_ID="select Status from Asset_Allocation where AllocationId=?";
	
	public static final String SELECT_ASSET ="SELECT assetid,assetname,assetdes,quantity from asset where assetid = ?";
	
	public static final String SELECT_EMPLOYEE = "SELECT empNo, ename, job, mgr, hireDate, dept_Id FROM Employee where empNo = ? ";
}
