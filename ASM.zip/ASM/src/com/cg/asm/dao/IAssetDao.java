package com.cg.asm.dao;

import java.util.List;

import com.cg.asm.entities.Asset;
import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.entities.UserMaster;
import com.cg.asm.exception.AssetException;

public interface IAssetDao {

	public UserMaster findLoginType(String uname, String pwd) throws AssetException;
	
	public Asset viewAsset(int assetId) throws AssetException;
	
	public int addAsset(Asset asset) throws AssetException;
	public int updateName(int id,String name) throws AssetException;
	public int updateDesc(int id,String desc) throws AssetException;
	public int updateQuantity(int id,int quantity) throws AssetException;
	
	public List<AssetAllocation> ViewStatusApproved()throws AssetException;
	public List<AssetAllocation> ViewStatusUnapproved()throws AssetException;

	public List<AssetAllocation> viewAllUnApprovedRequests() throws AssetException;
	public AssetAllocation viewAllocationDetails(int allocationId) throws AssetException;
}
