package com.cg.ams.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.asm.dao.AssetDaoImpl;
import com.cg.asm.entities.Asset;
import com.cg.asm.entities.AssetAllocation;
import com.cg.asm.entities.UserMaster;
import com.cg.asm.exception.AssetException;


public class TestAssetDao {
	static AssetDaoImpl dao;
	static Asset asset;
	static AssetAllocation allocation;
	static UserMaster user;
	@BeforeClass
	public static void init()
	{
	dao=new AssetDaoImpl();
	asset = new Asset();
	allocation = new AssetAllocation();
	user= new UserMaster();
	}
	
	/************************************
	 * Test case for loginTypeAdmin()
	 * 
	 ************************************/
	
	
	@Test
	public void loginTypeAdmin() throws AssetException
	{
		user=dao.findLoginType("deepthi", "vc");
		if(user!=null)
		{
			assertEquals("deepthi",user.getUserName());
			assertEquals("vc",user.getUserPassword());
			System.out.println("Admin Login Success");
		}
		else
		{
			System.out.println("Invalid Username/Password");
		}
	}
	
	/************************************
	 * Test case for loginTypeManager()
	 * 
	 ************************************/
	@Ignore
	@Test
	public void loginTypeManager() throws AssetException
	{
		user=dao.findLoginType("rithanya", "lydia");
		if(user!=null)
		{
			assertEquals("rithanya",user.getUserName());
			assertEquals("srinivasan",user.getUserPassword());
			System.out.println("Manager Login Success");
		}
		else
		{
			System.out.println("Invalid Username/Password");
		}
	}

	
	@Test
	public void loginTypeManager1() throws AssetException
	{
		user=dao.findLoginType("rithanya", "srinivasan");
		if(user!=null)
		{
			assertEquals("rithanya",user.getUserName());
			assertEquals("srinivasan",user.getUserPassword());
			System.out.println("Manager Login Success");
		}
		else
		{
			System.out.println("Invalid Username/Password");
		}
	}
	/************************************
	 * Test case for addAsset()
	 * 
	 ************************************/
	@Ignore
	@Test
	public void addAsset() throws AssetException
	{
		asset.setAssetId(410);
		asset.setAssetName("mouse");
		asset.setAssetDesc("optical mouse");
		asset.setQuantity(9);
		assertTrue("Asset Details Added Successfully", (dao.addAsset(asset)) >0 );
		System.out.println("Asset Details Added Successfully");
	}
	@Ignore
	@Test
	public void addAsset1() throws AssetException
	{
		asset.setAssetId(410);
		asset.setAssetName("mouse");
		asset.setAssetDesc("optical mouse");
		asset.setQuantity(9);
		Integer id= dao.addAsset(asset);
		assertNotNull(id);
		System.out.println("Asset Details Added Successfully");
	}
	
	/************************************
	 * Test case for modifyAssetName()
	 * 
	 ************************************/
	@Test
	public void modifyAssetName() throws AssetException
	{
		int id=410;
		String name="keyboard";
		assertTrue("Asset Name Updated Successfully", (	dao.updateName(id, name)) >0 );
		System.out.println("Asset Name Updated Successfully");
	}
	
	/************************************
	 * Test case for modifyAssetDescription()
	 * 
	 ************************************/
	@Test
	public void modifyAssetDescription() throws AssetException
	{
		int id=410;
		String desc="wireless keyboard";
		Integer update=dao.updateDesc(id, desc);
		assertNotNull(update);
		System.out.println("Asset Description Updated Successfully");
	}
	
	/************************************
	 * Test case for modifyAssetQuantity()
	 * 
	 ************************************/
	@Test
	public void modifyAssetQuantity() throws AssetException
	{
		int id=410;
		int quantity=10;
		assertTrue("Asset Quantity Updated Successfully", (	dao.updateQuantity(id, quantity)) >0 );
		System.out.println("Asset Quantity Updated Successfully");
	}
	
	@AfterClass					
	public static void afterClass()
	{
		dao=null;
		asset = null;
		allocation = null;
		user= null;
	}
	
}
