package com.lms.controller;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.lms.bean.CustomerDetails;
import com.lms.bean.LoanApplication;
import com.lms.bean.LoanProgramsOffered;
import com.lms.exception.LmsException;
import com.lms.service.ICustomerService;

@Controller
public class LoanController {

	@Autowired
	private ICustomerService customerService;
	
	@RequestMapping("/showHome")
	public ModelAndView showHomePage(@ModelAttribute("loans") LoanProgramsOffered bean,
			BindingResult result){
		ModelAndView modelview = new ModelAndView();
		
		
		if (result.hasErrors()) {
			modelview.setViewName("index");
			modelview.addObject("message", "Binding Failed");
		} else {
			try {
				List<LoanProgramsOffered> list = customerService.viewAll();
				modelview.setViewName("index");
				modelview.addObject("list", list);
			} catch (LmsException e) {
				modelview.setViewName("error");
				modelview.addObject("message", e.getMessage());
			}

		}
		return modelview;
	}
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomer(@RequestParam("programName") String programName){
		ModelAndView modelview = new ModelAndView();
	
			modelview.setViewName("register");
			modelview.addObject("name", programName );
		
		
		return modelview;
	}
	@RequestMapping("/registerCustomerDb")
	public ModelAndView insertCustomer(@ModelAttribute("customerDetails" )CustomerDetails customer,@RequestParam("programName") String programName ) throws LmsException{
		ModelAndView modelview = new ModelAndView();
		
		System.out.println(customer.getApplicantName());
		try {			
				int id = customerService.registerCustomer(customer);
				modelview.setViewName("loan");
				//modelview.addObject("programName", programName );
			modelview.addObject("name", programName);
			modelview.addObject("customer", customer);
			modelview.addObject("custid",id);
			LoanProgramsOffered loans=customerService.getSpecificLoan(programName);
			modelview.addObject("LoanProgram", loans);
		} catch (Exception e) {
			modelview.setViewName("register");
			modelview.addObject("programName", programName );
			e.printStackTrace();
		}
		return modelview;
	}
	@RequestMapping("/applyLoan")
	public ModelAndView applyloan(@ModelAttribute("LoanApplication" )LoanApplication application,@RequestParam("programName")String programName, @RequestParam("custId") int custId ) throws LmsException{
		ModelAndView modelview = new ModelAndView();
		try {
			
			LocalDate appDate = LocalDate.now();
			Date date = java.sql.Date.valueOf(appDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			date = cal.getTime();
			application.setApplicationDate(date);
			String prog= programName;
			System.out.println("--------------------"+ prog);
			application.setLoanProgram(prog);
			application.setStatus("unapproved");
			
		System.out.println("====================================="+custId);
			int id=customerService.applyLoan(application,custId);
		
			modelview.setViewName("applicationId");
			modelview.addObject("name", programName );
			modelview.addObject("id", (String.valueOf(id)));
		
		} catch (Exception e) {
			modelview.setViewName("register");
			modelview.addObject("name", programName );
			e.printStackTrace();
		}
		return modelview;
	}
	@RequestMapping("/status")
	public ModelAndView checkStatus(@RequestParam("applicationStatus")int applicationId) throws LmsException{
		ModelAndView modelview = new ModelAndView();
		System.out.println(applicationId);
		LoanApplication applicationStatus= customerService.viewApplicationStatus(applicationId);
		if(applicationStatus==null)
		{
			String message="Please provide a valid ID";
			modelview.setViewName("checkStatus");
			modelview.addObject("message", message);
		}
		else{
			String message="";
			modelview.setViewName("status");
			modelview.addObject("application", applicationStatus);
			modelview.addObject("message", message);
		}
		return modelview;
	}
	@RequestMapping("/statusCheck")
	public ModelAndView redirectStatusForm(){
		String message="";
		ModelAndView modelview= new ModelAndView();
		modelview.addObject("message", message);
		modelview.setViewName("checkStatus");
		return modelview; 
	}
}
