package com.lms.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "customer_details")
public class CustomerDetails
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator="customerIdSeq")
	@SequenceGenerator(name="customerIdSeq", sequenceName="customer_id_seq")
	private int customerId;
	

	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="applicationId")
	private LoanApplication applicationId;
	
	
	@Column(length=20)
	private String applicantName;
	@Temporal(TemporalType.DATE)
	private Date dob;
	
	@Column(length=10)
	private String maritalStatus;
	private long phoneNumber;
	private long mobileNumber;
	
	private int countOfDependents;
	
	@Column(length=20)
	private String emailId;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public LoanApplication getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(LoanApplication applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getCountOfDependents() {
		return countOfDependents;
	}

	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	
}