package com.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.bean.CustomerDetails;
import com.lms.bean.LoanApplication;
import com.lms.bean.LoanProgramsOffered;
import com.lms.dao.ICustomerDao;
import com.lms.exception.LmsException;

@Service
public class CustomerServiceImpl implements ICustomerService 
{
	@Autowired
	private ICustomerDao customerDao;
	

	
	
	@Override
	public int registerCustomer(CustomerDetails customer) throws LmsException {
		//logger.info("successful");
		return customerDao.registerCustomer(customer);
	}

	
	@Override
	public int applyLoan(LoanApplication loan, int custId) throws LmsException {
		//logger.info("successful");
		return customerDao.applyLoan(loan, custId);
	}

	@Override
	public LoanApplication viewApplicationStatus(int applicationId)
			throws LmsException {
		//logger.info("successful");
		return customerDao.viewApplicationStatus(applicationId);
	}


	@Override
	public List<LoanProgramsOffered> viewAll() throws LmsException {
		
		return customerDao.viewAll();
	}


	@Override
	public LoanProgramsOffered getSpecificLoan(String programName)
			throws LmsException {
		
		return customerDao.getSpecificLoan(programName);
	}

}
